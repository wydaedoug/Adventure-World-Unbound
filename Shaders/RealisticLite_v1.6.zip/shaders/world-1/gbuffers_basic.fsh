#version 330 compatibility

uniform sampler2D lightmap;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

void main() {
	color = glcolor * texture(lightmap, lmcoord);
	if (color.a < alphaTestRef) {
		discard;
	}

	// Same reasoning as gbuffers_textured.fsh — this program has no
	// reliable world position for its geometry, so explicitly mark
	// colortex1 as "no shadow data" rather than leaving whatever was
	// drawn underneath.
	normalOut = vec4(0.0);
}