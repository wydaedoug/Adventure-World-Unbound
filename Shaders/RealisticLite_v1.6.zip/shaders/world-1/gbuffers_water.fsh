#version 330 compatibility

// ============================================================
// RealisticLite - world-1/gbuffers_water.fsh  (Nether)
//
// Nether water (if any — mostly just lava here) gets the same color
// and opacity tuning as overworld water, but NO sun/moon specular
// glint. The Nether has no sun or moon, so there's no directional
// light to reflect.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;
in vec3 viewPos;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    color *= texture(lightmap, lmcoord);
    if (color.a < alphaTestRef) discard;

    // Same color/opacity tuning as overworld water
    color.r *= 1.08;
    color.g *= 1.08;
    color.b *= 0.88;
    color.a *= 0.78;

    // No sun/moon glint — Nether has no directional light
    normalOut   = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);
}
