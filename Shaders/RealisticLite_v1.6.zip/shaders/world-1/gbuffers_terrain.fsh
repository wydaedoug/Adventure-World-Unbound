#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_terrain.fsh
// Writes albedo to colortex0 and encoded view-space normal
// to colortex1 for use in the shadow bias calculation.
//
// HDR: colortex0 is now declared as a 16-bit float buffer (see
// composite.fsh for the directive itself, and why it has to live in a
// block comment). Emissive boosts below can exceed 1.0 and carry real
// radiance through to final.fsh's tonemap, instead of being clamped
// back to white at this stage.
//
// lmcoord.x is the RAW block-light coordinate (0 = no block light, ~1 =
// max, i.e. light level 15 — directly on/next to a torch, sea lantern,
// glowstone, redstone lamp, etc). Boosting off this rather than the final
// lightmap colour means full daylight (driven by lmcoord.y / sky light)
// is untouched — only actual light-emitting blocks and their immediate
// glow radius get brighter.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    color *= texture(lightmap, lmcoord);
    if (color.a < alphaTestRef) discard;

    // Emissive glow boost for torches, sea lanterns, glowstone, etc.
    // colortex0 is HDR now, so this is left as real radiance — no
    // clamp needed here. final.fsh's tonemap is the one place that
    // converts the full HDR range down to displayable [0,1].
    //
    // blockDominance: only let the block-light glow brighten a pixel
    // where block light (lmcoord.x) is actually the stronger of the two
    // raw lightmap channels. Without this, the boost looks at lmcoord.x
    // alone and stacks on top of whatever sky light (lmcoord.y, the
    // sun) already contributed — so a torch in broad daylight adds its
    // glow on top of full sunlight and blows out to an unrealistically
    // bright result. Real light doesn't sum like that outdoors: the
    // stronger source dominates and the weaker one contributes nothing
    // extra. Comparing the two channels directly and zeroing the boost
    // once sky light catches up to block light gives a "brightest light
    // wins" result instead of an additive one.
    //
    // Reach: the ramp's low edge starts at 0.05 — just above "no block
    // light at all" — instead of 0.3, so the glow now fades in gradually
    // over a much longer distance from the source than before. The high
    // edge (0.85, where it saturates to full strength) is unchanged, so
    // the brightest point right next to the source is exactly as bright
    // as it was — only how far the glow reaches before fading to nothing
    // has increased, along with how gradual that fade feels.
    // ============================================================
    // v1.2 — Natural distance falloff for block light.
    //
    // PROBLEM (v1.1): smoothstep(0.05, 0.85, lmcoord.x) creates a
    // PLATEAU — every pixel with lmcoord.x >= 0.85 (i.e. the source
    // block itself AND every block within ~1 block of it) gets the
    // SAME maximum boost. That flat top is why light spread looked
    // "even" instead of falling off naturally with distance.
    //
    // FIX: Replace the smoothstep with a power curve. pow(lmcoord.x, N)
    // preserves the peak (1.0 at the source) but steepens the falloff
    // so light gets gradually dimmer with distance from the source
    // instead of staying at max for the first block then dropping.
    //
    // This is the same technique Complementary Reimagined uses
    // (lib/lighting/mainLighting.glsl:351-353) — they remap lmcoord.x
    // through a steep power curve (x^8 blended with linear, then ^2.25).
    // We use a simpler pow(x, 3.0) that achieves the same natural
    // falloff shape without Complementary's tuning complexity.
    //
    // Effect of pow(lmcoord.x, 3.0) on the boost:
    //   lmcoord.x = 1.00 (at source)        → 1.000 (UNCHANGED peak)
    //   lmcoord.x = 0.85 (1 block away)     → 0.614 (was 1.0 — plateau removed)
    //   lmcoord.x = 0.70 (2 blocks away)    → 0.343 (was ~0.85)
    //   lmcoord.x = 0.50 (3-4 blocks away)  → 0.125 (was ~0.56)
    //   lmcoord.x = 0.20 (far)              → 0.008 (was ~0.19)
    //   lmcoord.x = 0.05 (very far)         → 0.000 (was ~0.0)
    //
    // The light source's own brightness is UNCHANGED — the peak
    // multiplier (1.6) and tint (0.45) are the same. Only the
    // falloff shape changes: tight bright core at the source,
    // smooth natural dimming with distance.
    //
    // Tune: lower exponent = wider/even spread, higher = tighter core.
    //   1.0 = linear (no falloff change)
    //   2.0 = moderate
    //   3.0 = natural torch-like (current)
    //   4.0 = tight core, fast falloff
    // ============================================================
    float blockDominance = smoothstep(0.0, 0.15, lmcoord.x - lmcoord.y);
    float emissiveBoost  = pow(lmcoord.x, 3.0) * blockDominance;
    color.rgb *= 1.0 + emissiveBoost * 1.6;

    const vec3 lightTint = vec3(1.0, 0.8, 0.55);
    color.rgb += lightTint * emissiveBoost * emissiveBoost * 0.45;

    // Encode view-space normal to [0, 1] range and store in colortex1.
    // Alpha = 1.0 signals that valid normal data is present.
    normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);

    // Raw block-light/sky-light coordinates, passed through so
    // composite.fsh can tell "actually unlit" from "lit but dark-coloured"
    // (see the ambient-floor code there for why this matters).
    lightmapOut = vec4(lmcoord, 0.0, 1.0);
}
