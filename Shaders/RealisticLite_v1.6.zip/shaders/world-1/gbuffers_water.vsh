#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_water.vsh  (v1.6, Water + Sun Specular)
//
// WHY THIS FILE EXISTS:
//   RealisticLite previously had no gbuffers_water program, so all
//   water fell through the Iris fallback chain
//     gbuffers_water -> gbuffers_terrain -> gbuffers_textured
//   and was rendered by gbuffers_terrain.fsh — which just multiplied
//   (texture * lightmap * vertexcolor). That gave vanilla blue water
//   at vanilla opacity, with no specular highlight from the sun.
//
//   This dedicated vertex shader lets us:
//     1. Pass the surface normal to the fragment shader (needed for
//        the GGX specular highlight — Complementary's reflectionBackground.glsl
//        uses normalM in its GGX call).
//     2. Pass the view-space position so the fragment shader can
//        compute VdotS (view · sun) and detect where the sun
//        reflection should appear.
// ============================================================

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 viewNormal;
out vec3 viewPos;

void main() {
    gl_Position = ftransform();
    texcoord   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord    = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor    = gl_Color;

    // View-space position — fragment shader needs this for:
    //   - normalize(viewPos) = view direction (for GGX half-vector)
    //   - length(viewPos)    = distance from camera (for distance-based effects)
    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

    // Transform vertex normal to view space (same as gbuffers_terrain.vsh).
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}
