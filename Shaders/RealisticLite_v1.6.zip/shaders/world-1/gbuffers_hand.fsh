#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_hand.fsh  (v1.3, Bug #2 fix)
// Dedicated fragment shader for the first-person hand / held-item
// view model.
//
// BUG BEING FIXED:
//   In first-person view, cutout blocks (leaves, seagrass, flowers)
//   were visible THROUGH the player's hand, while solid blocks
//   (stone, dirt) were correctly occluded. The hand was behaving
//   as if translucent over cutout geometry.
//
// ROOT CAUSE:
//   This pack previously had NO gbuffers_hand program. Per the Iris
//   docs (https://shaders.properties/current/reference/programs/gbuffers/),
//   the fallback chain for the hand is:
//     gbuffers_hand -> gbuffers_textured_lit -> gbuffers_textured
//   Since this pack also lacks gbuffers_textured_lit, the hand was
//   rendered by gbuffers_textured — the same program used by clouds,
//   weather, glint, beacon beams, particles, and spider eyes.
//   Iris applies hand-specific GL state (correct depth range with
//   MC_HAND_DEPTH, depth-write enabled, depth-test against world
//   geometry) ONLY when gbuffers_hand exists. Without it, the hand
//   inherited gbuffers_textured's GL state, which does not write
//   depth correctly for the hand view model — so cutout blocks
//   drawn earlier in the opaque pass bled through the hand's
//   alpha-tested pixels.
//
//   Solid blocks (stone, dirt) didn't bleed through because they
//   are fully opaque and wrote depth in the solid terrain pass
//   before the hand; the hand's colour write overwrote their colour
//   directly. Cutout blocks (leaves, grass, flowers) also wrote
//   colour, but at pixels where the hand's own alpha test discarded
//   the hand fragment, the cutout block colour underneath was what
//   remained visible — producing the see-through effect.
//
// THE FIX:
//   Create this dedicated gbuffers_hand program. Iris now routes
//   hand draw calls here and applies the correct hand GL state.
//   The shader logic itself is identical to gbuffers_textured.fsh
//   (texture * vertex colour * lightmap, alpha-tested, with the
//   colortex1 = vec4(0.0) sentinel that tells composite.fsh to
//   skip the shadow lookup for these pixels).
//
// WHY colortex1 = vec4(0.0):
//   The hand view model uses a camera-attached transform with
//   MC_HAND_DEPTH applied. composite.fsh's world-position
//   reconstruction (gbufferProjectionInverse / gbufferModelViewInverse)
//   can't correctly un-project these pixels, so we mark them as
//   "no shadow data" (alpha < 0.1) — composite.fsh then leaves
//   them fully lit. Same sentinel as gbuffers_textured.fsh.
//
// Reference:
//   - https://shaders.properties/current/reference/programs/gbuffers/
//   - https://shaders.properties/current/reference/macros/mc_hand_depth/
//   - https://shaders.properties/current/reference/buffers/depthtex/
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform vec3  sunPosition;       // v1.4 — for hand directional shading
uniform vec3  upPosition;        // v1.4 — for sunVisibility computation
uniform float rainStrength;      // v1.4 — for rain gate
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;  // v1.3 — from vertex shader

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    // v1.4 — Fix "hand behaving as translucent" bug.
    //
    // PROBLEM: Even after Task 2 (dedicated gbuffers_hand program) and
    // Task 19 (hand shadows), the hand was still behaving as translucent
    // — you could see terrain (including solid blocks, not just cutout)
    // through it. The transparency was direction/angle/sunlight dependent.
    //
    // ROOT CAUSE #1: The alpha test was applied AFTER multiplying by glcolor
    // and the lightmap texture. The vanilla lightmap's alpha channel (and
    // sometimes glcolor's alpha) can be < 1.0, which reduces color.a below
    // the 0.1 threshold. Pixels that should be visible were being discarded
    // — and discarded pixels don't write color OR depth, so the underlying
    // terrain showed through. The direction/sunlight dependence came from
    // the lightmap changing with time of day and block light levels.
    //
    // ROOT CAUSE #2: composite.fsh applied warm tint + fog + depth darkening
    // to hand pixels. The hand's depth is compressed by MC_HAND_DEPTH (~0.125),
    // which made composite.fsh's viewPos reconstruction produce bogus positions.
    // The warm tint code read colortex2 (which at discarded hand edge pixels
    // contained STALE block data underneath), causing blocks to show through.
    //
    // FIX: Apply alpha test to RAW texture alpha before multiplication (fixes #1).
    // Compute hand shading DIRECTLY here in gbuffers_hand.fsh and mark hand
    // pixels with alpha=0.5 sentinel so composite.fsh skips ALL post-processing (fixes #2).
    vec4 texColor = texture(gtexture, texcoord);

    // Alpha test on RAW texture alpha (before glcolor/lightmap multiplication)
    if (texColor.a < alphaTestRef) discard;

    // Now multiply RGB by glcolor and lightmap, but preserve the original alpha
    // so the output pixel is fully opaque (alpha = texColor.a, not reduced by lightmap)
    vec3 lightmapColor = texture(lightmap, lmcoord).rgb;
    color = vec4(texColor.rgb * glcolor.rgb * lightmapColor, texColor.a);

    // ============================================================
    // v1.4 — Hand directional shading computed HERE (not in composite.fsh).
    //
    // Adapted from Complementary's gbuffers_hand.glsl:98,147 — pre-baked
    // shadowMult = 0.5 + normal-based directional shading.
    //
    // By computing the shading here, we avoid composite.fsh's bogus viewPos
    // reconstruction (caused by MC_HAND_DEPTH compressed depth) and the
    // stale-data issues with colortex2 at discarded edge pixels.
    // ============================================================
    vec3  sunDir        = normalize(sunPosition);
    vec3  upDir         = normalize(upPosition);
    float SdotU         = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;

    // Normal-based directional shading
    float cosTheta    = clamp(dot(viewNormal, sunDir), 0.0, 1.0);
    float normalBoost = pow(cosTheta, 0.8) * 0.5;
    float shadowFactor = 0.5 + normalBoost;
    // Night gate — at night, hand keeps just the 0.5 base
    shadowFactor = mix(0.5, shadowFactor, sunVisibility);

    // Apply shading to the hand color
    color.rgb *= shadowFactor;

    // v1.4 — Hand sentinel: alpha = 0.5 tells composite.fsh to skip
    // ALL post-processing (shadows, warm tint, fog, depth darkening).
    // The hand color computed above is the FINAL color.
    normalOut = vec4(viewNormal * 0.5 + 0.5, 0.5);

    // Write lightmap coords (for completeness, though composite.fsh
    // won't read them for hand pixels anymore)
    lightmapOut = vec4(lmcoord, 0.0, 1.0);
}
