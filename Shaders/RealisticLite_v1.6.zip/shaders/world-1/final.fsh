#version 330 compatibility

// ============================================================
// RealisticLite - final.fsh  (v1.4, Bloom added)
// True last stage of the pipeline. composite.fsh has done all the
// scene lighting (shadows, vignette, exposure) in linear HDR space
// and left colortex0 as real, unbounded radiance. composite1/2/3
// have extracted the bright parts and Gaussian-blurred them into
// colortex3 (the bloom buffer). This stage adds the bloom back
// into the scene and then tonemaps the combined result down to a
// displayable [0,1] image.
//
// Adding bloom BEFORE the tonemap (not after) is critical: the
// bloom buffer carries real HDR radiance, and ACES needs to see
// the full combined range to compress it correctly. Adding bloom
// after tonemapping would clamp the glow to [0,1] and lose the
// HDR character of bright light sources.
// ============================================================

uniform sampler2D colortex0;  // HDR scene (post-composite lighting)
uniform sampler2D colortex3;  // Bloom buffer (post-composite3 blur)

in vec2 texcoord;

layout(location = 0) out vec4 color;

// ACES Filmic curve — Krzysztof Narkowicz's fitted approximation (2015),
// a standard, widely-published tonemap formula.
float ACESFilm(float x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

void main() {
    vec3 scene = texture(colortex0, texcoord).rgb;
    vec3 bloom = texture(colortex3, texcoord).rgb;

    // Add bloom to the scene while still in linear HDR space — BEFORE
    // the tonemap. This preserves the full radiance of bright light
    // sources and lets ACES compress the combined range naturally.
    //   0.8 = bloom strength. Raise for a stronger glow, lower for
    //   subtler bloom. 0.5 = subtle, 1.0 = strong, 1.5 = dreamy.
    const float bloomStrength = 0.5;
    vec3 c = scene + bloom * bloomStrength;

    // Tonemap luminance only, then rescale the colour to match, instead
    // of running ACESFilm on R, G, and B independently. Near the top of
    // the curve it flattens out — every channel converges toward roughly
    // the same ceiling regardless of how different the inputs were, which
    // bleaches bright, warm light (torches, lava, glowstone) toward pale
    // white instead of letting it stay warm. Tonemapping luminance and
    // rescaling keeps the actual hue/warmth intact while still compressing
    // brightness the same way.
    float luminance      = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float tonemappedLum  = ACESFilm(luminance);
    float scale          = tonemappedLum / max(luminance, 1e-4);

    color = vec4(clamp(c * scale, 0.0, 1.0), 1.0);
}
