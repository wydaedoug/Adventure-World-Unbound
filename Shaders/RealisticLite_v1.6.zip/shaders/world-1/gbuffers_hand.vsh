#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_hand.vsh  (v1.3, Bug #2 fix)
// Dedicated vertex shader for the first-person hand / held-item
// view model.
//
// WHY THIS FILE EXISTS:
// Without a dedicated gbuffers_hand program the hand fell through
// Iris's fallback chain
//   gbuffers_hand -> gbuffers_textured_lit -> gbuffers_textured
// and was rendered by gbuffers_textured — the SAME program shared
// with clouds, particles, beacon beams, weather, glint, and spider
// eyes. Those draw calls have very different depth-write / alpha-
// test needs than the hand, and sharing the program caused the
// classic "cutout blocks (leaves, seagrass, flowers) visible
// through the hand" artefact described at:
//   https://shaders.properties/current/reference/programs/gbuffers/
//
// Per the Iris docs, MC_HAND_DEPTH (the clip-space depth multiplier
// that pushes the hand view model close to the near plane so it
// always wins depth tests against world geometry) is applied
// automatically through the projection matrix for gbuffers_hand.
// Creating this file is what tells Iris to use the hand projection
// matrix and hand-specific GL state for these draw calls in the
// first place.
// ============================================================

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 viewNormal;  // v1.3 — surface normal for directional hand shading

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    // v1.3 — Transform vertex normal to view space.
    // Used by composite.fsh for normal-based directional shading on
    // the hand (cosTheta-based brightness — surfaces facing the sun
    // are brighter, surfaces facing away are darker).
    // Adapted from Complementary's gbuffers_hand vertex shader which
    // passes `normal` for the same purpose.
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}
