#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_block.fsh
// Emissive light-source boost. colortex0 is now a 16-bit float HDR
// buffer (declared in composite.fsh), so this is left as real
// radiance — no clamp needed, see gbuffers_terrain.fsh for details.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    color *= texture(lightmap, lmcoord);
    if (color.a < alphaTestRef) discard;

    // Wider reach, same peak, warm tint close to the source — same as
    // gbuffers_terrain.fsh. blockDominance ensures the boost only fires
    // where block light (lmcoord.x) is actually the stronger of the two
    // raw lightmap channels, so it no longer stacks on top of full sky
    // light (lmcoord.y) and blows out in daylight. See gbuffers_terrain.fsh
    // for the full rationale, including why only the ramp's low edge
    // moved (0.3 -> 0.05) — that extends the glow's reach and smooths
    // out its falloff without changing how bright it gets at the peak.
    // v1.2 — Natural distance falloff (same as gbuffers_terrain.fsh).
    // Replaced plateau'd smoothstep(0.05, 0.85, lmcoord.x) with
    // pow(lmcoord.x, 3.0) — preserves the peak at the source but
    // steepens the falloff so light dims naturally with distance.
    // See gbuffers_terrain.fsh for the full rationale and tuning
    // guide. Technique adapted from Complementary Reimagined's
    // block-light curve remapping (lib/lighting/mainLighting.glsl:351).
    float blockDominance = smoothstep(0.0, 0.15, lmcoord.x - lmcoord.y);
    float emissiveBoost  = pow(lmcoord.x, 3.0) * blockDominance;
    color.rgb *= 1.0 + emissiveBoost * 1.6;

    const vec3 lightTint = vec3(1.0, 0.8, 0.55);
    color.rgb += lightTint * emissiveBoost * emissiveBoost * 0.45;

    normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);
}
