#version 330 compatibility

// ============================================================
// RealisticLite - composite1.fsh  (v1.4, Bloom stage 1/3)
// Bright-pass extraction.
//
// Reads the HDR scene from colortex0 (post-composite lighting)
// and extracts pixels above a soft threshold into colortex3.
// colortex3 is a new RGBA16F buffer declared in shaders.properties.
//
// Because colortex0 is HDR (RGBA16F), light sources that got the
// emissive boost in gbuffers_terrain.fsh / gbuffers_block.fsh
// (torches, glowstone, sea lanterns, redstone lamps, etc.) carry
// real radiance values well above 1.0 here, so they bloom strongly.
// The sun (rendered by gbuffers_textured, no emissive boost) sits
// at ~1.05 after exposure — just above the threshold — so it
// blooms moderately. Regular sky and bright daylight surfaces
// (snow, sand) sit at or below 1.0 and don't bloom.
//
// Buffer flow:
//   reads:  colortex0 (main)  — HDR scene from composite
//   writes: colortex3 (alt)   — bright extract
//   After flip: main colortex3 = bright extract, main colortex0
//   preserved (flip disabled in shaders.properties).
// ============================================================

uniform sampler2D colortex0;

in vec2 texcoord;

/* RENDERTARGETS: 3 */
layout(location = 0) out vec4 bloom;

void main() {
    vec3 c = texture(colortex0, texcoord).rgb;

    // Soft-knee bright-pass.
    //   smoothstep(0.5, 1.5, luminance)
    //   → 0 for luminance <= 0.5  (no bloom — sky, dark surfaces)
    //   → 1 for luminance >= 1.5  (full bloom — torches, glowstone)
    //   → smooth transition for 0.5 < luminance < 1.5 (sun, bright edges)
    //
    // Tune:
    //   Raise both args to bloom fewer things (only torches/glowstone >2.0).
    //   Lower both args to bloom more (sun, bright sky, daylight snow).
    //   Widen the range for a softer transition, narrow for a harder cutoff.
    float luminance = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float amount = smoothstep(0.1, 0.9, luminance);

    bloom = vec4(c * amount, 1.0);
}
