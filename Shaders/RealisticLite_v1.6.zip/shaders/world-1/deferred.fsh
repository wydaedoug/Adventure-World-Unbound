#version 330 compatibility

uniform sampler2D colortex0;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    vec4 c = texture(colortex0, texcoord);

    // First lighting enhancement pass.
    c.rgb = pow(max(c.rgb, vec3(0.0)), vec3(0.95));
    c.rgb = (c.rgb - 0.5) * 1.08 + 0.5;

    // colortex0 is HDR (16-bit float) now — this is an intermediate
    // buffer write, not the final display output, so no clamp here.
    // final.fsh's ACES tonemap is what converts the full HDR range
    // down to [0,1] right before it's shown on screen.
    color = vec4(max(c.rgb, vec3(0.0)), c.a);
}
