#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_skybasic.vsh  (v1.8, Sky + Sun Glare)
//
// Vertex shader for the sky dome. Per the Iris docs
// (https://shaders.properties/current/reference/programs/gbuffers/),
// gbuffers_skybasic is the dedicated program for "sky color/horizon,
// stars, void" — without it, the sky falls through the chain
//   gbuffers_skybasic -> gbuffers_textured -> gbuffers_basic
// and gets rendered by gbuffers_textured, which just passes
// vanilla's flat sky colour through unchanged.
//
// This program lets us compute a proper sky gradient + sun/moon
// glare per pixel. We pass the view-space position so the fragment
// shader can compute VdotS (view · sun) and VdotU (view · up),
// which are the two key angular inputs for the glare formula.
// ============================================================

out vec3 viewDir;
out vec4 glcolor;

void main() {
    gl_Position = ftransform();
    // View-space position of this sky vertex — its normalized form
    // is the view direction at this pixel.
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    viewDir = viewPos.xyz;
    glcolor = gl_Color;
}
