#version 330 compatibility

// ============================================================
// RealisticLite - shadow.fsh
// Shadow map fragment shader.
// Alpha-tests foliage, fences, and transparent geometry
// so their holes don't cast solid rectangle shadows.
//
// Modified to use the block.properties ID system (ID 102) 
// to flawlessly discard water shadows.
// ============================================================

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

// 1. Receive the block ID from shadow.vsh
in float blockId;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 shadowColor;

void main() {
    // 2. Reconstruct the integer ID (add 0.5 to prevent float rounding errors)
    int id = int(blockId + 0.5);

    // 3. The Water Shadow Deletion Logic
    // If the block is mapped to ID 102 in block.properties, terminate it immediately.
    if (id == 102) {
        discard;
    }

    vec4 col = texture(gtexture, texcoord) * glcolor;

    // Discard fully transparent pixels (leaves, fences, glass panes, etc.)
    // so they don't cast a filled-rectangle shadow outline.
    if (col.a < 0.1) discard;

    // Output — shadowcolor0 is not sampled by composite.fsh (only
    // shadowtex0 depth is used), so the RGB value here is unused.
    // Kept as a minimal write; the GPU auto-writes depth regardless.
    shadowColor = vec4(0.0, 0.0, 0.0, 1.0);
}