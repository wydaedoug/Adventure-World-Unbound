#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

void main() {
	color = texture(gtexture, texcoord) * glcolor;
	color *= texture(lightmap, lmcoord);
	if (color.a < alphaTestRef) {
		discard;
	}

	// This program renders clouds, the held item/hand view model, weather,
	// and other things with no reliable world-space position (see the
	// "noShadowData" check in composite.fsh). Without this, colortex1 at
	// this pixel would just be whatever the last thing drawn here left
	// behind — e.g. distant terrain a cloud is drawn in front of — and
	// composite.fsh would run the shadow calculation using that stale
	// terrain normal against this cloud's own depth, producing wrong,
	// sometimes near-black results. Alpha < 0.1 here guarantees this
	// pixel is always correctly read as "leave fully lit, no shadow data".
	normalOut = vec4(0.0);
}