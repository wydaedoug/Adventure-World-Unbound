#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_terrain.vsh
// Outputs view-space normal for shadow bias in composite.
// ============================================================

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 viewNormal;

void main() {
    gl_Position = ftransform();
    texcoord   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord    = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor    = gl_Color;

    // Transform vertex normal to view space for normal-offset shadow bias
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}
