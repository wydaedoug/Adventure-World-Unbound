#version 330 compatibility

// ============================================================
// RealisticLite - world-1/gbuffers_skytextured.fsh  (Nether)
//
// The Nether has no sun or moon — the sky is just fog. This file
// is kept for Iris program-completeness (the program is still in
// the fallback chain) but does nothing special. Vanilla's texture
// is passed through unchanged.
// ============================================================

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;
in vec3 viewDir;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    // No sun/moon recolor, no horizon fade, no rain fade — Nether has
    // no sky bodies and no weather. Just pass through.
    normalOut = vec4(0.0);
}
