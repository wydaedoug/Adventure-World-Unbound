#version 330 compatibility

// ============================================================
// RealisticLite - world-1/gbuffers_skybasic.fsh  (Nether)
//
// The Nether has no real sky — the "sky" is just the fog color.
// This file passes vanilla's glcolor through unchanged. No sun/moon
// glare, no custom gradient, no horizon fade — none of that applies
// in the Nether.
// ============================================================

in vec3 viewDir;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

void main() {
    // Vanilla Nether sky color (fog color) — pass through unchanged
    color = vec4(glcolor.rgb, 1.0);
    normalOut = vec4(0.0);
}
