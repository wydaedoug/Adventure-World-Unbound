#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_skytextured.vsh  (v1.5, Sun recolor)
//
// Vertex shader for the sun and moon discs. Per the Iris docs
// (https://shaders.properties/current/reference/programs/gbuffers/),
// gbuffers_skytextured is the dedicated program for "sun and moon
// textures" — without it, the sun falls through the chain
//   gbuffers_skytextured -> gbuffers_textured -> gbuffers_basic
// and gets rendered by gbuffers_textured (the same program shared
// with clouds, particles, weather, glint, spider eyes), which just
// passes the vanilla sun texture through unchanged.
//
// We also pass the view-space position so the fragment shader can
// compute VdotS (view · sun) — used as a fallback for telling sun
// from moon on Iris versions that don't expose renderStage, and as
// a sanity check on versions that do.
// ============================================================

out vec2 texcoord;
out vec4 glcolor;
out vec3 viewDir;

void main() {
    gl_Position = ftransform();
    // View-space position of this sky vertex. For a fullscreen sky
    // quad this is a vector from the camera into the scene; its
    // normalized form is the view direction at this pixel.
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    viewDir = viewPos.xyz;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
}
