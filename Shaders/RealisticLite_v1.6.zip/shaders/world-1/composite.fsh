#version 330 compatibility

// ============================================================
// RealisticLite - composite.fsh
// Dynamic Shadow Mapping  (PCF soft shadows)
// + filmic tone mapping for contrast/colour grading
// ============================================================

// HDR pipeline: colortex0 is a true 16-bit float buffer, so emissive
// boosts (gbuffers_terrain.fsh, gbuffers_block.fsh) can exceed 1.0 and
// carry real radiance values all the way to final.fsh's tonemap instead
// of being pre-clamped to [0,1] at each stage. This is the buffer-format
// directive Iris looks for — it has to sit alone on its own line
// inside a block comment, because RGBA16F isn't a real GLSL symbol
// and Iris reads this line as plain text before compilation rather
// than injecting it as an actual declaration. (The previous attempt
// wrote it as a bare `const int` statement outside any comment, which
// is exactly what produced the "undeclared identifier" error — the
// real GLSL compiler tried to compile it as code and choked on the
// unknown name RGBA16F.)
/*
const int colortex0Format = RGBA16F;
*/

// ---- Scene inputs ----
uniform sampler2D colortex0;   // Final scene colour from deferred pass
uniform sampler2D colortex1;   // Encoded view-space normals (terrain/block/entity)
uniform sampler2D colortex2;   // Raw lightmap coords (block light, sky light) — not currently read here; still populated by the gbuffer stages if needed later
uniform sampler2D depthtex0;   // Non-linear scene depth

// ---- Shadow inputs ----
// sampler2DShadow performs hardware PCF-compatible depth comparison
uniform sampler2DShadow shadowtex0;  // Shadow depth map (all geometry)

// ---- Transformation matrices ----
uniform mat4 gbufferProjectionInverse;   // Clip → view space
uniform mat4 gbufferModelViewInverse;    // View  → world space
uniform mat4 shadowModelView;            // World → shadow-view space
uniform mat4 shadowProjection;           // Shadow-view → shadow-clip space

// ---- Light direction ----
// Position of the shadow-casting light in view space.
// Normalised = directional light vector.
uniform vec3 shadowLightPosition;

// Iris/vanilla-provided fog colour — already accounts for time of day,
// biome (e.g. blue underwater, grey Nether), and rain, so distance fog
// below always blends toward whatever colour is actually correct for
// the current situation without us having to work that out ourselves.
uniform vec3 fogColor;

// v1.4 — Sun-angle uniform. Iris exposes this as the sun's position in
// eye-space; its Y component tells us how high the sun is above the
// horizon, which we use to compute noonFactor (warm-orange at sunset /
// sunrise, white at noon) and sunVisibility (smooth day/night blend).
uniform vec3 sunPosition;

// v1.4 — Up vector in eye-space (always (0,1,0) transformed by the
// camera's roll; using it instead of a literal up avoids wrong results
// if the camera is ever tilted (e.g. by a mod or by irregular view
// matrices).
uniform vec3 upPosition;

// v1.4 — Rain strength 0..1, used to desaturate sun light toward grey
// on rainy days, matching Complementary's behaviour.
uniform float rainStrength;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

// ============================================================
// Shadow map distortion — must match shadow.vsh exactly.
// Warps NDC shadow coords so that the centre region of the
// shadow map (near the player) contains ~80% of all texels.
// ============================================================
float shadowDistortFactor(vec2 p) {
    return length(p) * 0.85 + 0.15;
}

vec2 distortShadow(vec2 p) {
    return p / shadowDistortFactor(p);
}

// ============================================================
// Position reconstruction
// ============================================================

// Screen UV + raw depth → view-space position
vec3 screenToViewPos(vec2 uv, float depth) {
    vec4 ndc  = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * ndc;
    return view.xyz / view.w;
}

// View-space position → world-relative-to-camera position
vec3 viewToWorldPos(vec3 viewPos) {
    return (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
}

// ============================================================
// Shadow coordinate calculation
// Converts a world-space position to shadow map UV + depth.
// ============================================================
vec3 getShadowCoord(vec3 worldPos) {
    // Into shadow clip space
    vec4 sc = shadowProjection * (shadowModelView * vec4(worldPos, 1.0));
    sc.xyz /= sc.w;                  // Perspective divide (ortho → no-op, but correct)

    // Apply the same distortion used in shadow.vsh
    sc.xy = distortShadow(sc.xy);

    // Convert NDC [-1, 1] to UV [0, 1]
    return sc.xyz * 0.5 + 0.5;
}

// ============================================================
// PCF shadow sampling — 8-tap rotated Poisson disk
// Returns 1.0 = fully lit, 0.0 = fully shadowed
// ============================================================
float sampleShadowPCF(vec3 shadowPos) {
    // Skip pixels outside the shadow map bounds
    if (any(lessThan   (shadowPos.xy, vec2(0.001))) ||
        any(greaterThan(shadowPos.xy, vec2(0.999)))) {
        return 1.0;
    }

    // Poisson disk kernel — 8 samples, balanced distribution
    const vec2 kernel[8] = vec2[](
        vec2(-0.9450, -0.3986),
        vec2( 0.9456, -0.7690),
        vec2(-0.0942, -0.9294),
        vec2( 0.3450,  0.2939),
        vec2(-0.8159,  0.4577),
        vec2(-0.3828,  0.2768),
        vec2( 0.9748,  0.7565),
        vec2( 0.4432, -0.9751)
    );

    // Spread in UV space — scaled to shadow map resolution (2048 in properties).
    // If you change shadowMapResolution in shaders.properties, update this too.
    const float texelSize = 1.0 / 2048.0;
    const float spread    = texelSize * 1.6;

    float shadow = 0.0;
    for (int i = 0; i < 8; i++) {
        // texture(sampler2DShadow, vec3) performs hardware depth comparison:
        // .xy = UV, .z = reference depth. Returns 1.0 if lit, 0.0 if occluded.
        shadow += texture(shadowtex0, vec3(shadowPos.xy + kernel[i] * spread,
                                           shadowPos.z));
    }
    return shadow / 8.0;
}

// ============================================================
// v1.4 — Time-of-day sun-light colour palette.
//
// Adapted from Complementary Reimagined r5.8.1
// (lib/colors/lightAndAmbientColors.glsl) — same hand-tuned
// warm-constant approach: four colours blended by sun position
// produce the golden-hour look the user asked for without any
// physical atmospheric simulation.
//
//   noonFactor    — 1.0 at noon, 0.0 at sunrise/sunset, smooth sqrt curve
//   sunVisibility — 1.0 when sun is up, 0.0 at night, smooth 0.125-wide
//                   twilight band (matches Complementary's calculation in
//                   program/gbuffers_terrain.glsl:62)
//
// Returns the FINAL sun-light colour in linear HDR space (can exceed 1.0).
// Applied only to the sun-lit portion of each pixel — block light and
// ambient are left untouched.
// ============================================================

// Returns the warm sun-light colour for the current time of day.
// Constants tuned to match Complementary's `lightAndAmbientColors.glsl`
// lines 6-26 (clear-weather) and 44-49 (rainy), then mixed by rain.
//
// v1.7: User feedback said the v1.4 palette was too yellow-orange.
// Pulled both noon and sunset colours toward a cooler/whiter hue:
//   noonClearLightColor:  (0.65, 0.55, 0.375)*2.05 -> (0.78, 0.74, 0.60)*1.9
//                         (less yellow, more white-daylight)
//   sunsetClearLightColor: vec3(0.64, 0.45, 0.3)  -> vec3(0.72, 0.55, 0.40)
//                          (still warm orange but less saturated)
//
// v1.9: User said sun light was still a little too yellow. Raised
// the blue channel and lowered red dominance further:
//   noonClearLightColor:  (0.78, 0.74, 0.60)*1.9 -> (0.75, 0.76, 0.72)*1.85
//                         (almost neutral white-daylight, very slight warm)
//   sunsetClearLightColor: vec3(0.72, 0.55, 0.40) -> vec3(0.74, 0.60, 0.48)
//                          (still warm but less saturated yellow)
vec3 getSunLightColor(float noonFactor, float sunVisibility, float rainFactor) {
    // ---- Clear-weather palette ----
    // Noon: near-neutral white-daylight (v1.9: even less yellow than v1.7)
    vec3 noonClearLightColor   = vec3(0.76, 0.69, 0.50) * 1.65;

    // Sunset/sunrise: warm but less saturated (v1.9: raised blue + green)
    float invNoonFactor = 1.0 - noonFactor;
    vec3 sunsetClearLightColor = pow(vec3(0.74, 0.60, 0.48),
                                     vec3(1.5 + invNoonFactor)) * 4.1;

    // Night: cold blue moonlight (Complementary: 0.9 * vec3(0.15, 0.14, 0.20))
    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);

    // Blend by sun elevation: night → day, with noon-vs-sunset driven by noonFactor
    vec3 dayLightColor   = mix(sunsetClearLightColor, noonClearLightColor, noonFactor);
    vec3 clearLightColor = mix(nightClearLightColor,  dayLightColor,      sunVisibility * sunVisibility);

    // ---- Rainy-weather palette (desaturated) ----
    // Day rain: muted warm grey (Complementary: vec3(0.21, 0.16, 0.13) * 0.85)
    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    // Night rain: very dim cool grey (Complementary: vec3(0.03, 0.035, 0.05))
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;

    // Final blend: clear vs rainy
    return mix(clearLightColor, rainLightColor, rainFactor);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec4  c     = texture(colortex0, texcoord);
    float depth = texture(depthtex0, texcoord).r;

    // Sky pixels (depth = 1.0) receive no shadow
    bool isSky = (depth >= 0.9999);

    // Camera-relative view-space position for this pixel — used both by
    // the shadow calculation below and by the distance fog further
    // down, so it's computed once here for any non-sky pixel.
    vec3 viewPos = vec3(0.0);
    if (!isSky) {
        viewPos = screenToViewPos(texcoord, depth);
    }

    // ============================================================
    // v1.4 — Hand pixel early exit.
    //
    // Hand pixels are marked with colortex1 alpha = 0.5 (set by
    // gbuffers_hand.fsh). The hand's color is ALREADY fully computed
    // in gbuffers_hand.fsh (texture * lightmap * directional shading),
    // so composite.fsh must NOT apply any post-processing to it.
    //
    // WHY: The hand's depth is compressed by MC_HAND_DEPTH (~0.125),
    // which makes viewPos reconstruction produce bogus positions. The
    // warm tint code reads colortex2 which at discarded hand edge
    // pixels contains STALE block data — causing blocks to show
    // through the hand. By exiting early, we skip shadows, warm tint,
    // fog, depth darkening, and exposure — the hand color passes
    // through unchanged.
    //
    // Hand shadows (v1.3/v1.4 feature) are computed directly in
    // gbuffers_hand.fsh now, so we don't lose that feature.
    // ============================================================
    vec4  handCheck    = texture(colortex1, texcoord);
    bool  isHandPixel  = (handCheck.a > 0.4 && handCheck.a < 0.6);

    if (isHandPixel) {
        // Hand color is final — just guard against negative values
        // and pass through. No shadow, no tint, no fog, no darkening.
        color = vec4(max(c.rgb, vec3(0.0)), c.a);
        return;
    }

    // --------------------------------------------------------
    // v1.4 — Time-of-day sun-light colour.
    //
    // Compute the warm hand-tuned sun colour BEFORE applying shadows,
    // so we can tint the sun-lit portion of each pixel later. We need
    // this regardless of whether the pixel is shadowed, because:
    //   - Lit pixels get the full warm tint
    //   - Shadowed pixels keep the ambient floor (no warm tint)
    //   - The tint is the SAME colour across the whole scene, so we
    //     compute it once here at the top.
    //
    // sunVisibility: how much the sun is above the horizon, with a
    // smooth 0.125-wide twilight band (matches Complementary's
    // program/gbuffers_terrain.glsl:62). At night this is 0.0, at
    // noon it's 1.0, and the transition around sunrise/sunset is
    // where the warm orange tint kicks in most strongly.
    //
    // noonFactor: 1.0 when the sun is directly overhead, 0.0 when
    // it's at the horizon. Computed as sqrt(sin(elevation)) for a
    // natural-feeling curve (matches Complementary's common.glsl:716).
    // --------------------------------------------------------
    vec3  sunDir     = normalize(sunPosition);
    vec3  upDir      = normalize(upPosition);
    float SdotU      = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float noonFactor    = sqrt(max(SdotU, 0.0));

    vec3  sunLightColor = getSunLightColor(noonFactor, sunVisibility, rainStrength);

    // --------------------------------------------------------
    // Dynamic shadow calculation
    // --------------------------------------------------------
    float shadowFactor = 1.0;

    if (!isSky) {
        // 1. Read colortex1 to determine surface type.
        //    alpha > 0.75   → terrain / block / entity / fluids: valid normal or fallback bias, full shadow
        //    alpha < 0.10   → NOTHING WRITTEN this frame (hand, clouds, weather, spider
        //                     eyes, glint, beaconbeam…). These either aren't real world
        //                     geometry or use a camera-attached transform that the world
        //                     camera's inverse matrices can't correctly un-project — so
        //                     skip the shadow lookup entirely rather than reconstruct a
        //                     bogus world position from them.
        vec4  normalSample = texture(colortex1, texcoord);
        float normalAlpha  = normalSample.a;

        bool noShadowData = (normalAlpha < 0.1);
        // v1.4: isHandPixel branch removed — hand pixels now exit early
        // at the top of main() before reaching this shadow code.
        bool hasNormal     = (normalAlpha > 0.75);

        if (noShadowData) {
            // No reliable world position available for this pixel — leave fully lit.
            shadowFactor = 1.0;

        } else {
            // 2. Reconstruct surface position in world space
            vec3 worldPos = viewToWorldPos(viewPos);

            // 3. Light direction + decoded view-space normal
            vec3  lightDir   = normalize(shadowLightPosition);
            vec3  viewNormal = normalSample.rgb * 2.0 - 1.0; // Decode [0,1] → [-1,1]
            float cosTheta   = hasNormal
                              ? clamp(dot(viewNormal, lightDir), 0.0, 1.0)
                              : 0.5;                     // Fallback: 45-degree surface

            // ---------------------------------------------------------------
            // FIX (v1.2): Sunset/sunrise horizontal-line acne on top block
            // surfaces — classic grazing-angle shadow acne.
            //
            // Symptom: at low sun elevations the top faces of blocks (which
            // face straight up while the sun is near the horizon) develop
            // faint horizontal banding. The previous bias scheme was a small
            // fixed-range mix(0.00015..0.00080) with no normal offset —
            // nowhere near enough once the sun drops below ~10° above the
            // horizon, and the block-grid-aligned depth discontinuities
            // between adjacent top faces bleed through as visible stripes.
            //
            // Two-part fix — the standard technique used by every production
            // Minecraft shader (BSL by Capt Tatsu, Complementary by EminGT,
            // SEUS by Sonic Ether):
            //
            //   (a) Normal-offset bias (primary): shift the world-space
            //       position used for the shadow lookup slightly ALONG the
            //       surface normal, toward the light. This lifts the
            //       receiver out of its own shadow-map texel, eliminating
            //       self-shadow acne on flat surfaces — exactly the
            //       top-of-block case. The offset scales with (1 - cosTheta)
            //       so it's zero for head-on lit surfaces (no peter-panning)
            //       and maximal at grazing angles (where acne is worst).
            //
            //   (b) Proper slope-scaled depth bias (secondary): replace the
            //       magic-number mix with the GPU Gems formula
            //         bias ∝ texelSize * tan(θ)
            //       where θ is the angle between surface normal and light.
            //       This scales geometrically with slope instead of lerping
            //       between two arbitrary constants, so it actually tracks
            //       the depth-error growth rate at grazing angles.
            //
            // References:
            //   - GPU Gems 2 Ch.11 "Shadow Mapping" (Everitt, Kilgard,
            //     McReynolds) — slope-scaled depth bias.
            //   - Andrew Lauritzen, "Fast and Accurate Shadow Mapping with
            //     Layered Shadow Maps" — receiver plane depth bias.
            //   - BSL shaders source (normal-offset implementation).
            //   - Complementary shaders source (refined bias tuning).
            // ---------------------------------------------------------------

            // World-space normal — view normal transformed back through the
            // inverse model-view matrix. w=0 because it's a direction.
            vec3  worldNormal = hasNormal
                               ? normalize((gbufferModelViewInverse * vec4(viewNormal, 0.0)).xyz)
                               : vec3(0.0);

            // Normal-offset in world blocks. 0.08 max — tuned for
            // shadowDistance=180. Larger values fix acne more aggressively
            // but cause shadows to "swim" along surfaces as the camera
            // moves; 0.08 is small enough to be invisible in practice.
            float offsetAmount   = 0.08 * (1.0 - cosTheta);
            vec3  shadowWorldPos = worldPos + worldNormal * offsetAmount;

            // Slope-scaled depth bias (GPU Gems formula). Cap slopeFactor
            // so true grazing cases rely on the grazing fade further down
            // rather than extreme depth bias (which would cause peter-
            // panning). texelSize matches shadowMapResolution=2048 — if
            // you change that in shaders.properties, update this too.
            const float shadowTexel = 1.0 / 2048.0;
            float slopeFactor = (cosTheta > 0.001)
                               ? sqrt(1.0 - cosTheta * cosTheta) / cosTheta
                               : 8.0;
            slopeFactor       = min(slopeFactor, 8.0);
            float angleBias   = shadowTexel * slopeFactor * 0.8;
            float distBias    = clamp(length(viewPos) / 48.0, 0.0, 1.0) * 0.00050;
            float totalBias   = angleBias + distBias;

            // 4. Project the offset position into shadow map UV space
            vec3 shadowPos  = getShadowCoord(shadowWorldPos);
            shadowPos.z    -= totalBias;         // Subtract bias from depth reference

            // 5. Sample shadow with Poisson-disk PCF soft filter
            float rawShadow = sampleShadowPCF(shadowPos);

            // 6. Preserve ambient component so shadowed areas are never pitch black.
            //    0.35 = ambient floor (tweak to taste: lower = darker shadows)
            float shadowLit = mix(0.42, 1.0, rawShadow);

            // 7. Darken (rather than try to correctly shadow) near-grazing
            //    surfaces — e.g. block side faces at solar noon, when the
            //    sun sits almost directly overhead and light rays run
            //    nearly parallel to vertical walls. Physically, a surface
            //    receiving light at a grazing angle gets almost no direct
            //    illumination from that light anyway, so fading toward
            //    the same dark/ambient floor used for ordinary shadow
            //    (rather than trying to resolve the degenerate, near-zero-
            //    resolution shadow-map sampling this angle causes) is both
            //    more correct-looking and hides the artifact.
            //    cosTheta is 1 = light hits the face head-on (unaffected),
            //    0 = light is perfectly parallel to the surface (unlit).
            float grazingFade = smoothstep(0.0, 0.15, cosTheta);
            shadowFactor = mix(0.42, shadowLit, grazingFade);
        }
    }

    // Apply shadow multiplier to scene colour
    c.rgb *= shadowFactor;

    // ============================================================
    // v2.2 — NETHER UNIVERSAL AMBIENT LIGHT
    //
    // PROBLEM: The Nether has no sun/moon, so areas far from lava or
    // torches are pitch black (lmcoord.x ≈ 0, no skylight). Real
    // Nether gameplay shows you can barely see in unlit caves.
    //
    // FIX: Add a small ambient light to EVERY non-sky pixel in the
    // Nether. This is ADDITIVE (not multiplicative) so it actually
    // fills in pitch-black areas instead of just brightening lit ones.
    //
    // The ambient is a warm dim red-orange — matches the Nether's
    // fiery atmosphere (lava glow permeating through the dimension).
    //
    // Tuning:
    //   0.04 is subtle — dark areas become visible but still feel dark
    //   0.08 is moderate — dark areas clearly visible
    //   0.12 is bright — eliminates most darkness
    // ============================================================
    if (!isSky) {
        const vec3 netherAmbient = vec3(0.055, 0.030, 0.020);  // warm dim red-orange
        c.rgb += netherAmbient;
    }

    // --------------------------------------------------------
    // NETHER: No warm sun tint — the Nether has no sun, so the
    // overworld's sun-palette tint code is skipped entirely.
    // --------------------------------------------------------

    // --------------------------------------------------------
    // Final HDR scene adjustments (Alpha 4.0) — depth darkening, exposure,
    // vignette. All still in linear HDR space; the actual tonemap curve
    // now lives in final.fsh, the true last stage before the screen.
    // --------------------------------------------------------
    // Subtle darkening of far geometry (REALISTICLITE_ALPHA32_DEPTH_VIS)
    c.rgb *= mix(1.0, 0.995, smoothstep(0.7, 1.0, depth));

    // Exposure: linear brightness multiplier applied before the filmic
    // curve. Raise this for a generally brighter scene; the tonemap in
    // final.fsh will keep highlights from clipping regardless of how
    // high this goes.
    const float exposure = 1.05;
    c.rgb *= exposure;

    // REALISTICLITE_ALPHA20 — subtle screen-edge vignette
    float vignette = distance(texcoord, vec2(0.5));
    vignette = 1.0 - smoothstep(0.35, 0.85, vignette) * 0.04;
    c.rgb *= vignette;

    // Very light distance fog. Completely invisible up close (nothing
    // happens before ~40 blocks), then ramps in very gradually, capped
    // at a 16% blend even at extreme render distances — meant as a hint
    // of atmosphere at the far edge of view, not actual visibility-
    // limiting fog. Skipped for sky pixels, since the sky is already
    // rendered in the correct colour for the current time/biome.
    if (!isSky) {
        float fogDist   = length(viewPos);
        float fogAmount = 1.0 - exp(-pow(max(fogDist - 40.0, 0.0) * 0.0035, 1.3));
        fogAmount = min(fogAmount, 0.16);
        c.rgb = mix(c.rgb, fogColor, fogAmount);
    }

    // No tonemap and no [0,1] clamp here anymore — colortex0 leaves this
    // stage as real, unbounded HDR radiance. final.fsh (the actual last
    // stage before the screen) is where that gets converted down to a
    // displayable image now. Just guard against negative values from any
    // upstream math.
    color = vec4(max(c.rgb, vec3(0.0)), c.a);
}

// REALISTICLITE_SHADOW_DYNAMIC   — full PCF soft shadow pass (Alpha 3.3)
// REALISTICLITE_GRAZING_FADE    — hides shadow-map artifacts on near-parallel
//                                 surfaces (e.g. walls at solar noon).
// REALISTICLITE_NORMAL_OFFSET   — v1.2: normal-offset bias + slope-scaled
//                                 depth bias. Fixes sunset/sunrise horizontal-
//                                 line acne on top block surfaces (the classic
//                                 grazing-angle shadow acne problem shared by
//                                 every Minecraft shader that doesn't do this).
// REALISTICLITE_WARM_SUNLIGHT   — v1.4: hand-tuned time-of-day sun colour
//                                 palette (noon/sunset/night/rain) applied to
//                                 sun-lit surfaces only. Adapted from
//                                 Complementary Reimagined r5.8.1
//                                 (lib/colors/lightAndAmbientColors.glsl).
// Note: ACES filmic tonemapping lives in final.fsh (the true last stage).
