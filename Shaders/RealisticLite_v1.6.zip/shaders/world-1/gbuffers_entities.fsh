#version 330 compatibility

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform vec4      entityColor;     // hit-flash / dye overlay
uniform float     alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    color *= texture(lightmap, lmcoord);
    // Apply entity colour (hit flash / dye) AFTER lighting so the overlay
    // is always at full intensity, matching vanilla behaviour where the
    // damage flash remains clearly visible even in deep shadow.
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
    if (color.a < alphaTestRef) discard;

    normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);
}
