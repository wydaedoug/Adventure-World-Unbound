#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_skytextured.fsh  (v1.5, Sun recolor)
//
// Dedicated fragment shader for the sun and moon discs.
//
// WHY THIS FILE EXISTS:
//   Without a dedicated gbuffers_skytextured program, the sun was
//   rendered by gbuffers_textured (fallback chain) which just passed
//   the vanilla sun texture through unchanged — a flat pale-yellow
//   disc with no warmth. This program recolors the sun disc to a
//   hand-tuned warm orange that matches Complementary Reimagined's
//   golden-hour look, with brightness modulated by sun elevation
//   (sunVisibility) and noon proximity (noonFactor). The moon is
//   left close to vanilla, just slightly dimmed to feel more like
//   reflected sunlight than a glowing disc.
//
// ADAPTED FROM:
//   Complementary Reimagined r5.8.1, program/gbuffers_skytextured.glsl
//   Specifically the isSun block (lines 76-79):
//     color.rgb = vec3(pow(dot(color.rgb, color.rgb) * 0.45, 6.0 - 5.0 * rainFactor));
//     color.rgb *= mix(vec3(1.1, 0.55, 0.0), vec3(0.35), rainFactor * 0.75) * 4.5;
//     color.rgb *= 0.25 + 0.75 * sunVisibility2 + 0.5 * noonFactor;
//   And the isMoon block (lines 81-83):
//     color.rgb *= smoothstep1(min1(length(color.rgb))) * 1.3;
//
// SUN VS MOON DETECTION:
//   Iris exposes a `renderStage` uniform in this program that tells
//   us exactly what's being drawn (MC_RENDER_STAGE_SUN or
//   MC_RENDER_STAGE_MOON). For older Iris versions where this was
//   buggy (sun rendered as MOON stage), and for non-Iris ports, we
//   fall back to VdotS = dot(viewDir, sunDir): the sun is on the
//   side of the sky the sun direction points to, the moon is on
//   the opposite side.
// ============================================================

uniform sampler2D gtexture;
uniform vec3  sunPosition;
uniform vec3  upPosition;
uniform float rainStrength;

// Iris-provided render stage. Values for this program:
//   MC_RENDER_STAGE_SUN  = sun disc being drawn
//   MC_RENDER_STAGE_MOON = moon disc being drawn
//   MC_RENDER_STAGE_NONE = anything else (custom skybox, etc.)
#ifdef IS_IRIS
uniform int renderStage;
#endif

in vec2 texcoord;
in vec4 glcolor;
in vec3 viewDir;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

// ============================================================
// v2.0 — Horizon fade for sun/moon.
//
// Adapted from Complementary Reimagined r5.8.1
// (lib/util/commonFunctions.glsl:40 — GetHorizonFactor).
//
// When the sun or moon gets close to the horizon (or goes below it),
// this function returns a value that smoothly fades to 0. Applied
// to both color.rgb (brightness) and color.a (opacity), this makes
// the sun/moon slowly disappear as it sets — instead of staying
// fully visible until it clips below the horizon.
//
// The SUN_MOON_HORIZON path (smoother, wider fade band) is used:
//   horizon = clamp((XdotU + 0.1) * 10.0, 0.0, 1.0)
//   return smoothstep²(horizon) — i.e. horizon² * (3 - 2*horizon), squared again
//
// XdotU is the angle between the view direction and the up vector:
//   XdotU = 1.0 → looking straight up → horizon = 1 (full visible)
//   XdotU = 0.0 → looking at horizon → horizon = smoothstep(0.1) ≈ 0.28 (fading)
//   XdotU = -0.1 → just below horizon → horizon = 0 (fully invisible)
// ============================================================
float getHorizonFactor(float XdotU) {
    float horizon = clamp((XdotU + 0.1) * 10.0, 0.0, 1.0);
    horizon = horizon * horizon * (3.0 - 2.0 * horizon);  // smoothstep
    return horizon * horizon;  // extra pow2 for a softer fade
}

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    if (color.a < 0.1) discard;

    // ---- Time-of-day factors (same as composite.fsh) ----
    vec3  sunDir        = normalize(sunPosition);
    vec3  upDir         = normalize(upPosition);
    vec3  vDir          = normalize(viewDir);
    float SdotU         = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
    float noonFactor    = sqrt(max(SdotU, 0.0));
    // v2.0 — view-direction · up vector. Used by getHorizonFactor()
    // to fade the sun/moon as it crosses the horizon.
    float VdotU         = dot(vDir, upDir);

    // ---- Sun vs moon detection ----
    float VdotS = dot(vDir, sunDir);
    bool isSun, isMoon;
    #ifdef IS_IRIS
        isSun  = (renderStage == MC_RENDER_STAGE_SUN);
        isMoon = (renderStage == MC_RENDER_STAGE_MOON);
        // Workaround for older Iris versions where sun rendered as
        // MC_RENDER_STAGE_MOON — if we're looking at the sun side,
        // trust VdotS over renderStage.
        if (VdotS > 0.0) { isSun = true; isMoon = false; }
    #else
        isSun  = (VdotS > 0.0);
        isMoon = !isSun;
    #endif

    // ---- Recolor ----
    if (isSun) {
        // Complementary's exact sun-recolor recipe:
        //   1. Take vanilla sun texture's luminance (dot(rgb, rgb) is
        //      a cheap luminance-ish measure that's > 0 only on the
        //      sun disc itself, not on transparent texels).
        //   2. pow(... * 0.45, 6.0 - 5.0 * rain) compresses bright
        //      values and sharpens the falloff in rain (so the sun
        //      gets visually smaller/sharper in rainy weather).
        //   3. Tint to pure white (v1.6: user asked for pure white sun
        //      texture — was near-white-yellow in v1.9, warm yellow in
        //      v1.7, deep orange in v1.5). Faded toward neutral grey
        //      vec3(0.5) by 75% of rain strength — sun looks pure
        //      white on clear days, cool grey on rainy days.
        //   4. Multiply by 4.5 to push above 1.0 (HDR — bloom will
        //      pick this up in composite1.fsh's bright-pass).
        //   5. Brightness modulation: dim when sun is low (sunVisibility2
        //      small at sunrise/sunset), bright at noon (noonFactor 1.0).
        color.rgb = vec3(pow(dot(color.rgb, color.rgb) * 0.45,
                             6.0 - 5.0 * rainStrength));
        // v1.6: vec3(1.0) is pure white (was 1.5, 1.45, 1.30 near-white-yellow in v1.9).
        // User asked for pure white sun texture.
        // Rain grey also pure grey (0.5).
        color.rgb *= mix(vec3(1.0), vec3(0.5), rainStrength * 0.75) * 4.5;
        color.rgb *= 0.25 + 0.75 * sunVisibility2 + 0.5 * noonFactor;
    } else if (isMoon) {
        // Slightly tone the moon — keeps it looking like reflected
        // sunlight instead of a glowing disc. smoothstep on the
        // texture's brightness softens the edge, the 1.3 multiplier
        // compensates so the brightest part of the moon stays visible.
        // (Complementary: smoothstep1(min1(length(color.rgb))) * 1.3)
        color.rgb *= smoothstep(0.0, 1.0, min(length(color.rgb), 1.0)) * 1.3;
    }

    // ============================================================
    // v2.0 — Horizon fade (the key fix for this task).
    //
    // Applied to BOTH color.rgb (brightness) and color.a (opacity)
    // so the sun/moon smoothly disappears as it crosses the horizon,
    // instead of staying fully visible until it clips below.
    //
    // Complementary applies this only to color.rgb (line 84 of their
    // skytextured). We also apply it to color.a for a cleaner fade —
    // without the alpha fade, the sun disc would stay at full opacity
    // and just get darker, which looks like a dimming red disc rather
    // than a disappearing sun.
    //
    // getHorizonFactor returns:
    //   1.0 when looking high in the sky (VdotU > 0)
    //   smoothly fades to 0 as VdotU approaches -0.1 (just below horizon)
    //   0.0 when VdotU <= -0.1 (below horizon — fully invisible)
    // ============================================================
    float horizonFade = getHorizonFactor(VdotU);
    color.rgb *= horizonFade;
    color.a   *= horizonFade;

    // Rain fade — sun/moon get dimmer in rain (matching Complementary's
    // alpha multiplier at line 99).
    color.a *= 1.0 - 0.8 * rainStrength;

    // Sky pixels (depth = 1.0) skip the shadow and tint code in
    // composite.fsh, so colortex1 here is just a sentinel to keep
    // the buffer in a defined state. vec4(0.0) = "no shadow data".
    normalOut = vec4(0.0);
}
