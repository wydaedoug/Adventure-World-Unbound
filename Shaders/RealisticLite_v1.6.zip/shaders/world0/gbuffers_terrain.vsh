#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_terrain.vsh
// Outputs view-space normal for shadow bias in composite.
// ============================================================

// 1. Ingest the block data array from OptiFine/Iris
in vec4 mc_Entity;

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 viewNormal;

// 2. Declare the output variable to carry the ID to the fragment shader
out float blockId;

void main() {
    // 3. Extract the ID (defined in block.properties)
    blockId = mc_Entity.x;

    gl_Position = ftransform();
    texcoord   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord    = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor    = gl_Color;

    // Transform vertex normal to view space for normal-offset shadow bias
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
}
