#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_skybasic.fsh  (v1.14, Custom Sky Gradient)
//
// Renders the sky dome with a FULL custom gradient (Option B),
// replacing vanilla's `glcolor` entirely. This is the only way
// to get smooth control over the horizon-to-zenith transition at
// sunset — vanilla's gradient is too sharp (~30-40px transition
// band), and Options A/C (mixing toward a fixed color / estimating
// horizon color) didn't work for the user.
//
// TECHNIQUE:
// Adapted from Complementary Reimagined r5.8.1
// (lib/atmospherics/sky.glsl:11-99 — GetSky() function).
// Complementary uses 4 colors (zenith/middle/horizon/sunset)
// blended by VdotU with a separate sunset mix on top.
//
// SIMPLIFIED VERSION:
// We use 3 colors (zenith/middle/horizon) blended by VdotU, with
// a sunset color mixed in based on invNoonFactor. The colors are
// tuned to match our v1.9 sun palette (less yellow than v1.4).
//
// KEY DIFFERENCE FROM VANILLA:
// Vanilla's gradient is `glcolor = horizon * (1-VdotU) + zenith * VdotU`
// — a simple 2-color linear blend with a narrow transition zone
// at sunset (where horizon is warm and zenith is blue, the linear
// blend produces a sharp edge because the colors are very different).
// Our gradient uses a 3-color blend with a MIDDLE color between
// zenith and horizon — the middle color acts as a buffer that
// widens the transition zone, producing a smooth gradient instead
// of a sharp edge.
//
// KEY DIFFERENCE FROM v1.10/v1.12/v1.13:
// Previous attempts ADDED a sunset mix on top of vanilla's color.
// This version REPLACES vanilla's color entirely with our own
// computed gradient — full control, no vanilla artifacts.
// ============================================================

uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform vec3 skyColor;  // vanilla's biome/tint-aware sky color — used as base tint

in vec3 viewDir;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

// ============================================================
// Time-of-day sun color palette — must stay in sync with
// composite.fsh and gbuffers_water.fsh. (v1.9 values.)
// ============================================================
vec3 getSunLightColor(float noonFactor, float sunVisibility, float rainFactor) {
    vec3 noonClearLightColor   = vec3(0.76, 0.69, 0.50) * 1.65;
    float invNoonFactor = 1.0 - noonFactor;
    vec3 sunsetClearLightColor = pow(vec3(0.74, 0.60, 0.48),
                                     vec3(1.5 + invNoonFactor)) * 4.1;
    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);

    vec3 dayLightColor   = mix(sunsetClearLightColor, noonClearLightColor, noonFactor);
    vec3 clearLightColor = mix(nightClearLightColor,  dayLightColor,      sunVisibility * sunVisibility);

    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;

    return mix(clearLightColor, rainLightColor, rainFactor);
}

void main() {
    // ---- View direction & sun angle ----
    vec3  nViewPos     = normalize(viewDir);
    vec3  sunDir       = normalize(sunPosition);
    vec3  upDir        = normalize(upPosition);
    float VdotS        = dot(nViewPos, sunDir);
    float VdotU        = dot(nViewPos, upDir);     // 1 = zenith, 0 = horizon, -1 = nadir
    float SdotU        = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
    float noonFactor    = sqrt(max(SdotU, 0.0));
    float invNoonFactor = 1.0 - noonFactor;        // 0 at noon, 1 at sunset/sunrise

    // ============================================================
    // v1.9 — ALL-BLUE SKY (user's blue, lighter at horizon, deeper at zenith)
    //
    // User said yellow didn't look good — make the whole sky blue
    // (93, 123, 190). To avoid a flat look, we vary the brightness
    // from lighter blue at the horizon to deeper blue at the zenith,
    // mimicking natural atmospheric depth (sky is brighter near the
    // horizon due to more air scattering, darker overhead).
    //
    // 4-stop gradient (horizon → zenith), all in the user's blue hue:
    //   0.00: (170, 190, 230) light blue   — horizon (brighter)
    //   0.35: (93,  123, 190) user's blue  — middle (the anchor)
    //   0.70: (65,  90,  150) deeper blue  — upper sky
    //   1.00: (40,  60,  110) deep blue    — zenith (darkest)
    // ============================================================

    // User's blue + 3 brightness variations (same hue, different lightness)
    vec3 c_light  = vec3(170.0, 190.0, 230.0) / 255.0;  // horizon — brighter blue
    vec3 c_blue   = vec3(93.0,  123.0, 190.0) / 255.0;  // user's blue (the anchor)
    vec3 c_deep   = vec3(65.0,  90.0,  150.0) / 255.0;  // upper sky
    vec3 c_zenith = vec3(40.0,  60.0,  110.0) / 255.0;  // zenith — darkest blue

    // Clamp VdotU to [0, 1] for the sky (above horizon)
    float v = clamp(VdotU, 0.0, 1.0);

    // 3-segment blend with smoothstep
    vec3 finalSky;
    if (v < 0.35) {
        finalSky = mix(c_light, c_blue, smoothstep(0.0, 0.35, v));
    } else if (v < 0.70) {
        finalSky = mix(c_blue, c_deep, smoothstep(0.35, 0.70, v));
    } else {
        finalSky = mix(c_deep, c_zenith, smoothstep(0.70, 1.0, v));
    }

    // ---- NIGHT DARKENING ----
    // At night, the sky darkens toward deep blue
    vec3 nightSky = vec3(0.015, 0.025, 0.050);
    finalSky = mix(nightSky, finalSky, sunVisibility);

    // ---- RAIN DESATURATION ----
    // Overcast sky goes grey
    float skyLum = dot(finalSky, vec3(0.2126, 0.7152, 0.0722));
    finalSky = mix(finalSky, vec3(skyLum) * 0.7, rainStrength * 0.6);

    // ---- SKY GROUND DARKENING ----
    // Below horizon (VdotU < 0), darken smoothly
    float groundDarken = 1.0 + min(VdotU, 0.0);
    groundDarken = groundDarken * groundDarken;
    groundDarken = groundDarken * groundDarken;
    finalSky *= groundDarken;

    color = vec4(finalSky, 1.0);

    // ---- Sun/Moon glare (Complementary's formula, on top of custom sky) ----
    // VdotSML: positive when looking at the active sky body.
    float VdotSML = sunVisibility > 0.5 ? VdotS : -VdotS;

    if (VdotSML > 0.0) {
        float glareScatter = 3.0 * (2.0 - clamp(VdotS * 1000.0, 0.0, 1.0));
        glareScatter *= 1.0 - 0.75 * rainStrength * rainStrength;

        float VdotSM4 = pow(abs(VdotS), glareScatter);
        float visfactor = 0.075;
        float glare = visfactor / (1.0 - (1.0 - visfactor) * VdotSM4) - visfactor;
        glare *= 0.7;
        glare *= 1.0 - 0.8 * rainStrength;

        vec3 glareColor;
        if (sunVisibility > 0.5) {
            glareColor = getSunLightColor(noonFactor, sunVisibility, rainStrength) * 1.4;
        } else {
            glareColor = 0.9 * vec3(0.15, 0.14, 0.20) * 1.2;
        }

        float glareLum = dot(glareColor, vec3(0.2126, 0.7152, 0.0722));
        glareColor = mix(glareColor, vec3(glareLum), rainStrength);

        color.rgb += glareColor * glare;
    }

    // Sky pixels (depth = 1.0) skip the shadow and tint code in
    // composite.fsh, so colortex1 here is just a sentinel.
    normalOut = vec4(0.0);
}
