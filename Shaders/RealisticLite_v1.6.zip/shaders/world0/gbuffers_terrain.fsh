#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_terrain.fsh
// Writes albedo to colortex0 and encoded view-space normal
// to colortex1 for use in the shadow bias calculation.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;

// 1. Receive the block ID from gbuffers_terrain.vsh
in float blockId;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

void main() {
    // 2. Reconstruct the integer ID
    int id = int(blockId + 0.5);

    color = texture(gtexture, texcoord) * glcolor;
    color *= texture(lightmap, lmcoord);
    if (color.a < alphaTestRef) discard;

    // Emissive glow boost for torches, sea lanterns, glowstone, etc.
    float blockDominance = smoothstep(0.0, 0.15, lmcoord.x - lmcoord.y);
    
    // THE DAYLIGHT OVERRIDE (ID 105)
    // Force fire, lava, and torches to always glow at maximum intensity, 
    // bypassing the sky-light suppression so they burn bright even at noon.
    if (id == 105) {
        blockDominance = 0.1;
    }
    
    float emissiveBoost  = pow(lmcoord.x, 3.0) * blockDominance;
    color.rgb *= 1.0 + emissiveBoost * 1.6;

    const vec3 lightTint = vec3(1.0, 0.8, 0.55);
    color.rgb += lightTint * emissiveBoost * emissiveBoost * 0.45;

    // 3. THE SHADOW BYPASS & NORMAL OUTPUT
    if (id == 105) {
        // Output vec4(0.0) to drop the alpha channel to 0.0. 
        // This triggers the 'noShadowData' boolean in composite.fsh, 
        // ensuring lava and fire are never darkened by physical shadows.
        normalOut = vec4(0.0);
    } else {
        // Give the normal vectors back to the pipeline so composite.fsh 
        // has the geometry data required to calculate shadows and SSS curves.
        normalOut = vec4(viewNormal * 0.5 + 0.5, 1.0);
    }

    // 4. THE FOLIAGE FLAG
    // If the block is ID 101, write 1.0. Otherwise, write 0.0.
    float isPlanarFoliage = (id == 101) ? 1.0 : 0.0;

    // Raw block-light/sky-light coordinates are passed in X and Y.
    // We hijack the previously unused Z channel (3rd parameter) to send the flag.
    lightmapOut = vec4(lmcoord, isPlanarFoliage, 1.0);
}