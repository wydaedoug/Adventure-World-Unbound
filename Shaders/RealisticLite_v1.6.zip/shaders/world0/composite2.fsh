#version 330 compatibility

// ============================================================
// RealisticLite - composite2.fsh  (v1.4, Bloom stage 2/3)
// Horizontal Gaussian blur of the bright-pass.
//
// Reads colortex3 (bright extract from composite1), applies a
// 9-tap separable Gaussian blur along X, writes to colortex4.
//
// The spread factor (4.0) widens the effective kernel: instead
// of sampling at texel offsets [0,1,2,3,4], we sample at
// [0,4,8,12,16]. This gives a much wider, softer glow for the
// same 9-tap cost. The Gaussian weights still sum to 1.0, so
// energy is preserved.
//
// Buffer flow:
//   reads:  colortex3 (main)  — bright extract from composite1
//   writes: colortex4 (alt)   — horizontally-blurred bloom
//   After flip: main colortex4 = H-blur, main colortex0 and
//   colortex3 preserved.
// ============================================================

uniform sampler2D colortex3;

in vec2 texcoord;

/* RENDERTARGETS: 4 */
layout(location = 0) out vec4 bloom;

void main() {
    vec2 texSize = vec2(textureSize(colortex3, 0));
    float texel  = 1.0 / texSize.x;

    // 9-tap Gaussian weights (normalized, symmetric).
    //   w[0] = center tap, w[1..4] = paired offsets
    // Sum = 0.227027 + 2*(0.1945946 + 0.1216216 + 0.054054 + 0.016216) = 1.0
    const float weights[5] = float[](
        0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216
    );

    // Spread > 1 stretches the kernel for a wider, softer glow
    // without adding more taps. 4.0 gives a clearly visible halo
    // around light sources at 1080p/1440p; lower for a tighter
    // glow, raise for a hazier one.
    const float spread = 1.0;

    vec3 result = texture(colortex3, texcoord).rgb * weights[0];
    for (int i = 1; i < 5; i++) {
        float offset = texel * spread * float(i);
        result += texture(colortex3, texcoord + vec2(offset, 0.0)).rgb * weights[i];
        result += texture(colortex3, texcoord - vec2(offset, 0.0)).rgb * weights[i];
    }

    bloom = vec4(result, 1.0);
}
