#version 330 compatibility

// ============================================================
// RealisticLite - composite.fsh
// Dynamic Shadow Mapping  (PCF soft shadows)
// + filmic tone mapping for contrast/colour grading
// ============================================================

/*
const int colortex0Format = RGBA16F;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex0;
uniform sampler2DShadow shadowtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

float shadowDistortFactor(vec2 p) {
    return length(p) * 0.85 + 0.15;
}

vec2 distortShadow(vec2 p) {
    return p / shadowDistortFactor(p);
}

vec3 screenToViewPos(vec2 uv, float depth) {
    vec4 ndc  = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = gbufferProjectionInverse * ndc;
    return view.xyz / view.w;
}

vec3 viewToWorldPos(vec3 viewPos) {
    return (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
}

vec3 getShadowCoord(vec3 worldPos) {
    vec4 sc = shadowProjection * (shadowModelView * vec4(worldPos, 1.0));
    sc.xyz /= sc.w;
    sc.xy = distortShadow(sc.xy);
    return sc.xyz * 0.5 + 0.5;
}

float sampleShadowPCF(vec3 shadowPos) {
    if (any(lessThan(shadowPos.xy, vec2(0.001))) ||
        any(greaterThan(shadowPos.xy, vec2(0.999)))) {
        return 1.0;
    }

    const vec2 kernel[8] = vec2[](
        vec2(-0.9450, -0.3986), vec2( 0.9456, -0.7690),
        vec2(-0.0942, -0.9294), vec2( 0.3450,  0.2939),
        vec2(-0.8159,  0.4577), vec2(-0.3828,  0.2768),
        vec2( 0.9748,  0.7565), vec2( 0.4432, -0.9751)
    );

    const float texelSize = 1.0 / 2048.0;
    const float spread    = texelSize * 1.6;

    float shadow = 0.0;
    for (int i = 0; i < 8; i++) {
        shadow += texture(shadowtex0, vec3(shadowPos.xy + kernel[i] * spread, shadowPos.z));
    }
    return shadow / 8.0;
}

vec3 getSunLightColor(float noonFactor, float sunVisibility, float rainFactor) {
    vec3 noonClearLightColor   = vec3(0.76, 0.69, 0.50) * 1.65;
    float invNoonFactor = 1.0 - noonFactor;
    vec3 sunsetClearLightColor = pow(vec3(0.74, 0.60, 0.48), vec3(1.5 + invNoonFactor)) * 4.1;
    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);
    vec3 dayLightColor   = mix(sunsetClearLightColor, noonClearLightColor, noonFactor);
    vec3 clearLightColor = mix(nightClearLightColor,  dayLightColor,      sunVisibility * sunVisibility);
    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;
    return mix(clearLightColor, rainLightColor, rainFactor);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec4  c     = texture(colortex0, texcoord);
    float depth = texture(depthtex0, texcoord).r;
    bool isSky = (depth >= 0.9999);

    vec3 viewPos = vec3(0.0);
    if (!isSky) {
        viewPos = screenToViewPos(texcoord, depth);
    }

    vec4  handCheck    = texture(colortex1, texcoord);
    bool  isHandPixel  = (handCheck.a > 0.4 && handCheck.a < 0.6);

    if (isHandPixel) {
        color = vec4(max(c.rgb, vec3(0.0)), c.a);
        return;
    }

    vec3  sunDir        = normalize(sunPosition);
    vec3  upDir         = normalize(upPosition);
    float SdotU         = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float noonFactor    = sqrt(max(SdotU, 0.0));

    vec3  sunLightColor = getSunLightColor(noonFactor, sunVisibility, rainStrength);

    // --------------------------------------------------------
    // Dynamic shadow Setup
    // --------------------------------------------------------
    float shadowFactor    = 1.0;
    float skyLightAmt     = 0.0;
    float isPlanarFoliage = 0.0;

    if (!isSky) {
        vec4  normalSample   = texture(colortex1, texcoord);
        vec4  lightmapSample = texture(colortex2, texcoord);
        float normalAlpha    = normalSample.a;
        
        skyLightAmt     = lightmapSample.g; 
        isPlanarFoliage = lightmapSample.b; 

        bool noShadowData = (normalAlpha < 0.1);
        bool hasNormal    = (normalAlpha > 0.75);

        if (noShadowData) {
            shadowFactor = 1.0;
        } else {
            vec3 worldPos = viewToWorldPos(viewPos);
            vec3 lightDir = normalize(shadowLightPosition);
            
            // 1. TRUE PHYSICAL NORMAL
            // We save the actual geometry data for the shadow map bias calculations.
            vec3 realViewNormal = normalSample.rgb * 2.0 - 1.0; 
            
            // 2. FAKE OPTICAL NORMAL
            // We bend the normal upward strictly for the lighting aesthetic.
            vec3 lightingNormal = realViewNormal;
            if (isPlanarFoliage > 0.5) {
                lightingNormal = upDir; 
            }
            
            // --- LIGHTING CALCULATION (Uses Fake Normal) ---
            float rawNdotL   = dot(lightingNormal, lightDir);
            float cosTheta   = hasNormal ? clamp(rawNdotL, 0.0, 1.0) : 0.5;

            // --- SHADOW BIAS CALCULATION (Uses True Normal) ---
            // We use the real normals so at noon, realCosTheta on vertical grass is ~0.0.
            // This ensures the offsetAmount maximizes to 0.08, pushing the pixel 
            // safely out of the vertical shadow map geometry!
            float realNdotL  = dot(realViewNormal, lightDir);
            float realCosTheta = hasNormal ? clamp(realNdotL, 0.0, 1.0) : 0.5;

            vec3  worldNormal = hasNormal ? normalize((gbufferModelViewInverse * vec4(realViewNormal, 0.0)).xyz) : vec3(0.0);
            
            float offsetAmount = 0.08 * (1.0 - realCosTheta);
            
            // The user's requested tweak: A tiny micro-offset specifically for grass
            // to ensure the X-planes never self-intersect their shadows at noon.
            if (isPlanarFoliage > 0.5) {
                offsetAmount += 0.02; 
            }
            
            vec3  shadowWorldPos = worldPos + worldNormal * offsetAmount;
            
            // Slope-scaled depth bias also must use the True Geometry
            const float shadowTexel = 1.0 / 2048.0;
            float slopeFactor = (realCosTheta > 0.001) ? sqrt(1.0 - realCosTheta * realCosTheta) / realCosTheta : 8.0;
            slopeFactor       = min(slopeFactor, 8.0);
            float angleBias   = shadowTexel * slopeFactor * 0.8;
            float distBias    = clamp(length(viewPos) / 48.0, 0.0, 1.0) * 0.00050;
            float totalBias   = angleBias + distBias;

            // Sample the shadow map
            vec3 shadowPos  = getShadowCoord(shadowWorldPos);
            shadowPos.z    -= totalBias;
            float rawShadow = sampleShadowPCF(shadowPos);

            // Calculate final lit shadow value
            float shadowLit = mix(0.42, 1.0, rawShadow);

            // Foliage doesn't need grazing fade because we forced its lighting normal upward
            float grazingFade = mix(smoothstep(0.0, 0.15, cosTheta), 1.0, isPlanarFoliage);
            
            // Final Shadow Factor
            shadowFactor = mix(0.42, shadowLit, grazingFade);
        }
    }

    // Apply clean shadows
    c.rgb *= shadowFactor;

    // --------------------------------------------------------
    // Warm Sun-Light Tint
    // --------------------------------------------------------
    if (!isSky) {
        float sunInfluence = skyLightAmt * shadowFactor * sunVisibility;
        float tintLum   = dot(sunLightColor, vec3(0.2126, 0.7152, 0.0722));
        float whiteRef  = 1.0;
        vec3  tintScale = sunLightColor / max(tintLum, 1e-4) * mix(1.0, tintLum / whiteRef, 0.5);

        const float tintStrength = 0.85;
        vec3  finalTint  = mix(vec3(1.0), tintScale, tintStrength);
        c.rgb = mix(c.rgb, c.rgb * finalTint, sunInfluence);
    }

    // HDR and Fog adjustments
    c.rgb *= mix(1.0, 0.995, smoothstep(0.7, 1.0, depth));
    const float exposure = 1.05;
    c.rgb *= exposure;

    float vignette = distance(texcoord, vec2(0.5));
    vignette = 1.0 - smoothstep(0.35, 0.85, vignette) * 0.04;
    c.rgb *= vignette;

    if (!isSky) {
        float fogDist   = length(viewPos);
        float fogAmount = 1.0 - exp(-pow(max(fogDist - 40.0, 0.0) * 0.0035, 1.3));
        fogAmount = min(fogAmount, 0.16);
        c.rgb = mix(c.rgb, fogColor, fogAmount);
    }

    color = vec4(max(c.rgb, vec3(0.0)), c.a);
}