#version 330 compatibility

// ============================================================
// RealisticLite - gbuffers_water.fsh  (v1.6, Water + Sun Specular)
//
// Two changes from the previous behaviour (water rendered by
// gbuffers_terrain.fsh):
//
//   1. WATER COLOUR / OPACITY TUNING
//      Vanilla water is a fairly saturated blue with low transparency.
//      The user asked for "slightly less blue and slightly more
//      transparent". We do both:
//        - Reduce the blue channel by 12% and boost the red/green by
//          8% — pulls the colour toward a teal/cyan rather than pure
//          blue, matching what real water looks like in daylight.
//        - Multiply alpha by 0.78 — lets you see more of the riverbed
//          / ocean floor through the water surface.
//      The shifts are deliberately subtle ("slightly") — they should
//      feel like a refinement, not a complete recolour.
//
//   2. SUN-ONLY SPECULAR HIGHLIGHT  (the user's main request)
//      Adds a bright glint on the water surface where the sun's
//      reflection aligns with the camera's view direction — the
//      classic "sun glitter on water" effect. ONLY the sun is
//      reflected; terrain reflections are NOT included (the user
//      was explicit about that).
//
//      Technique adapted from Complementary Reimagined:
//        - lib/lighting/ggx.glsl: GGX() microfacet BRDF for sharp
//          specular highlights. We use a simplified version of the
//          GGX function (the WATER_REFLECT_QUALITY < 2 path) — that's
//          enough for a sun glint without needing the area-light
//          approximation.
//        - lib/lighting/mainLighting.glsl:34: highlightColor =
//          normalize(pow(lightColor, 0.37)) * (0.3 + 1.5 * sunVisibility²)
//          * (1 - 0.85 * rainFactor). We reuse the same warm sun
//          palette from composite.fsh's getSunLightColor() so the
//          specular glint matches the warm sun colour.
//        - lib/materials/materialMethods/reflectionBackground.glsl:24:
//          specularHighlight = GGX(normal, view, sunDir, NdotL, smoothness);
//          skyReflection += specularHighlight * highlightColor *
//          shadowMult * highlightMult * invRainFactor.
//          We follow the same pattern but apply only the specular
//          component (no sky reflection, no terrain reflection — just
//          the sun glint).
//
//      Smoothness: water is one of the smoothest surfaces in the game.
//      Complementary uses ~0.96 for water smoothness; we use 0.92 to
//      keep the glint slightly broader and more visible.
// ============================================================

uniform sampler2D lightmap;
uniform sampler2D gtexture;
uniform vec3  sunPosition;
uniform vec3  upPosition;
uniform float rainStrength;
uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 viewNormal;
in vec3 viewPos;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;
layout(location = 2) out vec4 lightmapOut;

// ============================================================
// GGX microfacet BRDF — simplified for water sun glint.
//
// Adapted from Complementary's lib/lighting/ggx.glsl, taking the
// WATER_REFLECT_QUALITY < 2 code path (no area-light approximation).
// This computes a sharp specular highlight where the reflected sun
// direction aligns with the view direction — exactly the "sun on
// water" glint the user asked for.
//
//   normalM   — surface normal in view space
//   nViewPos  — normalized view-space position (= view direction)
//   lightVec  — normalized sun direction in view space
//   NdotL     — dot(normal, lightVec), clamped to [0, 1]
//   smoothnessG — 0..1, water is ~0.92 here
// ============================================================
float ggxSunSpecular(vec3 normalM, vec3 nViewPos, vec3 lightVec,
                     float NdotL, float smoothnessG) {
    // Remap smoothness — Complementary: sqrt1(smoothnessG * 0.9 + 0.1)
    smoothnessG = sqrt(smoothnessG * 0.9 + 0.1);
    float roughnessP = 1.35 - smoothnessG;
    float roughness  = roughnessP * roughnessP;
    roughness = roughness * roughness;  // pow2(roughness)

    // Half vector between view and light directions
    vec3 halfVec = normalize(lightVec - nViewPos);

    float dotLH = clamp(dot(halfVec, lightVec), 0.0, 1.0);
    float dotNV = dot(normalM, -nViewPos);

    // NoHSquared approximation (WATER_REFLECT_QUALITY < 2 path)
    float VoL = dot(-nViewPos, lightVec);
    float dotNH = 2.0 * NdotL * dotNV * length(halfVec) - VoL;
    dotNH = min(dotNH, 1.0);
    dotNH = dotNH * dotNH;  // pow2

    // GGX D term
    float denom = dotNH * roughness - dotNH + 1.0;
    float D = roughness / (3.14159265358979 * denom * denom);

    // Fresnel (Schlick approx)
    float f0 = 0.05;
    float F = exp2((-5.55473 * dotLH - 6.98316) * dotLH) * (1.0 - f0) + f0;

    // Final specular value
    float NdotLmax0M = sqrt(sqrt(NdotL * max(dot(normalM, lightVec), 0.0)));
    float specular = max(NdotLmax0M * D * F / (dotLH * dotLH), 0.0);
    specular = specular / (0.125 * specular + 1.0);  // tone-map to prevent blowout

    return specular;
}

// ============================================================
// Time-of-day sun color (same palette as composite.fsh — duplicated
// here because gbuffers programs can't read composite's helper
// function. Constants must stay in sync with composite.fsh's
// getSunLightColor() if you tune one, tune the other.)
//
// v1.7: less yellow-orange (same change as composite.fsh).
// v1.9: a little less yellow (same change as composite.fsh).
// ============================================================
vec3 getSunLightColor(float noonFactor, float sunVisibility, float rainFactor) {
    vec3 noonClearLightColor   = vec3(0.76, 0.69, 0.50) * 1.65;
    float invNoonFactor = 1.0 - noonFactor;
    vec3 sunsetClearLightColor = pow(vec3(0.74, 0.60, 0.48),
                                     vec3(1.5 + invNoonFactor)) * 4.1;
    vec3 nightClearLightColor  = 0.9 * vec3(0.15, 0.14, 0.20);

    vec3 dayLightColor   = mix(sunsetClearLightColor, noonClearLightColor, noonFactor);
    vec3 clearLightColor = mix(nightClearLightColor,  dayLightColor,      sunVisibility * sunVisibility);

    vec3 dayRainLightColor   = vec3(0.21, 0.16, 0.13) * 0.85 + noonFactor * vec3(0.0, 0.02, 0.06);
    vec3 nightRainLightColor = vec3(0.03, 0.035, 0.05);
    vec3 rainLightColor      = mix(nightRainLightColor, dayRainLightColor, sunVisibility * sunVisibility) * 2.5;

    return mix(clearLightColor, rainLightColor, rainFactor);
}

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    color *= texture(lightmap, lmcoord);
    if (color.a < alphaTestRef) discard;

    // -------------------------------------------------------
    // 1. WATER COLOUR / OPACITY TUNING (user request)
    // -------------------------------------------------------
    // Slightly less blue: pull the colour toward teal/cyan by
    // reducing blue and boosting red+green.
    color.r *= 1.08;
    color.g *= 1.08;
    color.b *= 0.88;

    // Slightly more transparent: multiply alpha by 0.78 so more of
    // the riverbed shows through. Vanilla water alpha is ~0.65 in
    // most biomes, so this drops it to ~0.51 — clearly more see-
    // through but still recognizably water.
    color.a *= 0.78;

    // -------------------------------------------------------
    // 2. SUN + MOON SPECULAR HIGHLIGHT
    //    (v1.7: added moon glint at night)
    // -------------------------------------------------------
    // The moon is in the opposite direction of the sun in vanilla
    // Minecraft. We compute both glints and add them — the active
    // one is selected automatically by the NdotL gate (only the
    // light source on the same side as the surface normal produces
    // a non-zero specular).
    vec3  sunDir        = normalize(sunPosition);
    vec3  moonDir       = -sunDir;                       // moon is opposite sun
    vec3  upDir         = normalize(upPosition);
    vec3  nViewPos      = normalize(viewPos);
    float SdotU         = dot(sunDir, upDir);
    float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;
    float sunVisibility2 = sunVisibility * sunVisibility;
    float noonFactor    = sqrt(max(SdotU, 0.0));

    // Moon visibility — symmetric to sun: 1 when moon is high, 0 when
    // it's below horizon, smooth twilight band. MdotU = -SdotU.
    float MdotU         = -SdotU;
    float moonVisibility = clamp(MdotU + 0.0625, 0.0, 0.125) / 0.125;
    float moonVisibility2 = moonVisibility * moonVisibility;

    // Surface normal in view space.
    vec3  normalM = normalize(viewNormal);
    float NdotL_sun  = clamp(dot(normalM, sunDir), 0.0, 1.0);
    float NdotL_moon = clamp(dot(normalM, moonDir), 0.0, 1.0);
    float NdotV      = clamp(dot(normalM, -nViewPos), 0.0, 1.0);

    // Water smoothness — slightly broader glint than Complementary's
    // 0.96 so it's more visible.
    float smoothness = 0.92;

    // ---- SUN GLINT (day) ----
    float sunSpecular = ggxSunSpecular(normalM, nViewPos, sunDir, NdotL_sun, smoothness);
    vec3  sunLightCol = getSunLightColor(noonFactor, sunVisibility, rainStrength);
    vec3  sunHighlight = normalize(pow(sunLightCol, vec3(0.37)))
                        * (0.3 + 1.5 * sunVisibility2)
                        * (1.0 - 0.85 * rainStrength);
    vec3  sunGlint = sunSpecular * sunHighlight * NdotV * 0.6 * sunVisibility;

    // ---- MOON GLINT (night) ----
    // v1.7 — user asked for moon glint at night. Uses the same GGX
    // function but with the moon direction and a cool blue moonlight
    // colour. Complementary's nightClearLightColor = 0.9 * vec3(0.15, 0.14, 0.20)
    // — we use a slightly brighter version (×1.6) so the glint is
    // actually visible (moonlight is very dim, a literal match would
    // produce a near-invisible glint).
    //
    // Smoothness is slightly higher (0.95 vs 0.92) so the moon glint
    // is tighter/sharper than the sun glint — visually distinct, and
    // physically reasonable (moonlight is a point source reflection
    // of sunlight off the moon's surface, which appears smaller than
    // the sun disc from Earth).
    float moonSpecular = ggxSunSpecular(normalM, nViewPos, moonDir, NdotL_moon, 0.95);
    vec3  moonLightCol = 0.9 * vec3(0.15, 0.14, 0.20) * 1.6;
    vec3  moonHighlight = normalize(pow(moonLightCol, vec3(0.37)))
                         * (0.3 + 1.5 * moonVisibility2)
                         * (1.0 - 0.85 * rainStrength);
    // 0.4 multiplier — dimmer than sun glint because moonlight is
    // much weaker than sunlight. Raise to 0.6 for a more visible
    // moon glint, lower to 0.25 for subtler.
    vec3  moonGlint = moonSpecular * moonHighlight * NdotV * 0.4 * moonVisibility;

    color.rgb += sunGlint + moonGlint;

    // -------------------------------------------------------
    // Encode normal + write lightmap (same as gbuffers_terrain.fsh)
    // -------------------------------------------------------
    normalOut   = vec4(viewNormal * 0.5 + 0.5, 1.0);
    lightmapOut = vec4(lmcoord, 0.0, 1.0);
}
