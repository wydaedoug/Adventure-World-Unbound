#version 330 compatibility

// ============================================================
// RealisticLite - world1/deferred.fsh  (End — Sky Rendering)
//
// v2.9.3 — Renders the End sky in this fullscreen deferred pass.
//
// PROBLEM (v2.9.2): gbuffers_skybasic only renders the horizon band
// in the End — the upper sky is cleared to black by vanilla and
// never reaches the gbuffers_skybasic program. So our purple sky +
// stars only appeared at the horizon, not overhead.
//
// FIX: Move sky rendering to deferred.fsh (a fullscreen pass that
// runs on every pixel). We detect sky pixels via depthtex0 (depth =
// 1.0 = sky) and apply the purple sky + ender stars to ALL sky
// pixels, including the upper sky.
//
// This is the same approach Complementary uses — they render the End
// sky in their deferred1 pass, not in gbuffers_skybasic.
// ============================================================

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform vec3  upPosition;
uniform mat4  gbufferProjectionInverse;
uniform float frameTimeCounter;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

// ============================================================
// Hash-based noise for procedural stars
// ============================================================
float enderStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

// ============================================================
// HSV to RGB (for time-varying hue)
// ============================================================
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

// ============================================================
// GetEnderStars — adapted from Complementary's enderStars.glsl
// ============================================================
vec3 getEnderStars(vec3 viewPos, float VdotU, vec3 skyColor) {
    vec3 wpos = normalize(viewPos * 1000.0);

    vec3 starCoord = 0.65 * wpos / (abs(wpos.y) + length(wpos.xz));
    vec2 starCoord2 = starCoord.xz * 0.5;
    if (VdotU < 0.0) starCoord2 += 100.0;

    float starFactor = 1024.0;
    starCoord2 = floor(starCoord2 * starFactor) / starFactor;

    float star = 1.0;
    star *= enderStarNoise(starCoord2.xy);
    star *= enderStarNoise(starCoord2.xy + 0.1);
    star *= enderStarNoise(starCoord2.xy + 0.23);
    star = max(star - 0.7, 0.0);
    star *= star;

    vec3 enderStars = star * skyColor * 3000.0;

    float absVdotU = abs(VdotU);
    float VdotUM2 = (1.0 - absVdotU) * (1.0 - absVdotU);
    enderStars *= min(VdotUM2 + 0.015, 0.05) + 0.015;

    float VdotUM3 = smoothstep(0.0, 0.25, absVdotU);
    enderStars *= pow(VdotUM3, 0.5);

    return enderStars * 0.5;
}

void main() {
    vec4 c = texture(colortex0, texcoord);
    float depth = texture(depthtex0, texcoord).r;

    // ---- Detect sky pixels (depth = 1.0) ----
    bool isSky = (depth >= 0.9999);

    if (isSky) {
        // ---- Reconstruct view direction from screen UV + depth ----
        vec4 ndc = vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * ndc;
        viewPos.xyz /= viewPos.w;
        vec3 nViewPos = normalize(viewPos.xyz);

        vec3 upDir = normalize(upPosition);
        float VdotU = dot(nViewPos, upDir);

        // ---- Time-varying rainbow color ----
        // Cycles through ALL hues of the rainbow over ~60 seconds.
        // hue goes 0→1→0: red → orange → yellow → green → cyan → blue → purple → magenta → red
        float hue = mod(frameTimeCounter * 0.017, 1.0);
        vec3 endSkyColor = hsv2rgb(vec3(hue, 0.6, 0.18)) * 1.65;

        // ---- Base sky: brighter toward horizon ----
        float absVdotU = abs(VdotU);
        float horizonFactor = pow(1.0 - absVdotU, 2.0);
        vec3 horizonColor = endSkyColor * 1.5;
        vec3 skyColor = mix(endSkyColor, horizonColor, horizonFactor);

        // ---- Add ender stars (concentrated near horizon) ----
        skyColor += getEnderStars(nViewPos, VdotU, endSkyColor);

        // ---- Below horizon: darken ----
        if (VdotU < 0.0) {
            float groundDarken = 1.0 + VdotU;
            groundDarken = groundDarken * groundDarken;
            skyColor *= groundDarken;
        }

        // Replace the pixel color with our sky color
        c.rgb = skyColor;
    } else {
        // Non-sky pixels: original deferred enhancement
        c.rgb = pow(max(c.rgb, vec3(0.0)), vec3(0.95));
        c.rgb = (c.rgb - 0.5) * 1.08 + 0.5;
    }

    color = vec4(max(c.rgb, vec3(0.0)), c.a);
}
