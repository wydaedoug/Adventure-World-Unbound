#version 330 compatibility

// ============================================================
// RealisticLite - world1/gbuffers_skybasic.fsh  (End)
//
// v2.9.3 — Simplified. The End sky is now rendered in deferred.fsh
// (a fullscreen pass) because gbuffers_skybasic only renders the
// horizon band in the End — the upper sky is cleared to black by
// vanilla and never reaches this program.
// ============================================================

in vec3 viewDir;
in vec4 glcolor;

/* RENDERTARGETS: 0,1 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 normalOut;

void main() {
    // Pass vanilla color through — deferred.fsh will handle the sky
    color = vec4(glcolor.rgb, 1.0);
    normalOut = vec4(0.0);
}
