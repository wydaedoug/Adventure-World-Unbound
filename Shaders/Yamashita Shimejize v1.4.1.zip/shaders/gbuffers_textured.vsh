#version 120

#define OVERWORLD
#define IS_GBUFFERS_TEXTURED

#include "/program/gbuffers_textured_legacy.vsh"
