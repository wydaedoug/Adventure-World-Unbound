#version 430 compatibility

#include "/program/gbuffers_entities_translucent.fsh"
