/* RENDERTARGETS: 0,1,3,4,5 */

#include "/p/8foepqev1c.fsh"
