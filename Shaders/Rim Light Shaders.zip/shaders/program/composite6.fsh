/* RENDERTARGETS: 2,3 */

#include "/p/yqngyhk6pk.fsh"
