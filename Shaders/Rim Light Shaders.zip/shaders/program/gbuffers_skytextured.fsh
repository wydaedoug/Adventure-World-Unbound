/* RENDERTARGETS: 0,1,2 */

#include "/p/9ij0vgg4g3.fsh"
