/* RENDERTARGETS: 0,8 */

#include "/p/qn6bv8dzgj.fsh"
