/* RENDERTARGETS: 7,1 */

#include "/p/jpts1rhta2.fsh"
