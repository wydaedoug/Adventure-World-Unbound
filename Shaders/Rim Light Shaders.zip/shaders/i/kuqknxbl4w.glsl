#ifndef HOVERING_GLSL
#define HOVERING_GLSL

float _2kkryz(vec3 _ct0cij) {
return 0.0;
}

#endif
