#version 430 compatibility

#include "/program/gbuffers_entities.fsh"
