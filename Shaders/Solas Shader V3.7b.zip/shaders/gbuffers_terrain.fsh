#version 130

#define FSH
#define OVERWORLD

#include "/programs/gbuffers_terrain.glsl"