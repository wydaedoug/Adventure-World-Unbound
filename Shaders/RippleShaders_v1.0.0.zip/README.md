# RippleShaders

A customized fork of **Sundial Lite** by GeForceLegend, modified by **EptuneStudios** as **RippleShaders**.

## Credits

- **Sundial Lite** - Original shaderpack by [GeForceLegend](https://github.com/GeForceLegend/Sundial-Lite)
- **EptuneStudios** - Custom modifications and fork

## License

This shaderpack is licensed under the [GNU General Public License v3.0 or later (GPL-3.0-or-later)](LICENSE).

Sundial Lite is Copyright (C) 2026 GeForceLegend. This fork maintains all original copyright notices and complies with the GPL-3.0-or-later license terms.

## Changes from Sundial Lite

The following modifications have been made to the original Sundial Lite shaderpack:

### Successfully Implemented

#### Underwater Turbulence
- Added wavy screen distortion when underwater
- Triggers automatically when `isEyeInWater == 1`
- Uses layered sine/cosine waves for organic movement
- Configurable: strength (3.0), speed (1.0), scale (1.0)
- Found in `Composite14.frag`

#### Motion Blur Enhancement
- Increased default motion blur strength from 1.0 to 2.0
- Provides more noticeable motion blur effect out of the box
- Found in `Composite10.frag`

#### Godrays
- Added radial blur godray effect emanating from the sun
- Samples only sky pixels (`depth == 1.0`) to avoid torch/light source contamination
- Includes angle-based fade and sun visibility checks
- Configurable: strength (1.5), samples, length, density
- Found in `Composite14.frag`

#### Ore Glow (Emissive Ores)
- All vanilla ore blocks now emit a high-contrast glow
- Includes: Coal, Iron, Copper, Gold, Lapis, Diamond, Emerald, Redstone, Nether Gold, Nether Quartz, Ancient Debris, and all Deepslate variants
- Uses ID 24576 (high-contrast emissive category)
- Found in `block.properties`

#### Metal Block Reflections
- Diamond, Iron, and Gold blocks now have hardcoded metallic properties
- Diamond: smoothness 0.95, metalness 0.0 (non-metallic but smooth)
- Iron: smoothness 0.9, metalness 230/255 (hardcoded metal ID 230)
- Gold: smoothness 0.95, metalness 231/255 (hardcoded metal ID 231)
- Found in `Terrain.frag` and `block.properties`

#### Water Wave Style
- Modified wave rotations, scales, motion vectors, and layer weights
- Creates a different wave character compared to default Sundial Lite
- Found in `libs/Water.glsl`

#### Foliage Wave Speed
- Doubled default plant wave speed from 1.0 to 2.0
- Foliage sways noticeably faster by default
- Configurable via menu slider
- Found in `settings/GlobalSettings.glsl`

#### Letterbox (Cinematic Bars)
- Added cinematic black bars effect
- Disabled by default (must be enabled via menu or `#define LETTERBOX`)
- Configurable size (default 0.1)
- Found in `Composite14.frag`
