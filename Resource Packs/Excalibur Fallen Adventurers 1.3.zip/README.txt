# Realm RPG: Fallen Adventurers for Excalibur
══════════════════════════════════════════════════════════════════════════

  	This mod support was created by Guardian and is maintained by ruseki_ and Guardian
        - You should have the Excalibur Resource Pack for this Add-On Pack to blend properly.
        - Report bugs with the pack to @Ruseki in the Excalibur Discord Channel.
        - I will make updates to the pack as necessary and time allows.


    All credit to Maffhew for Excalibur
        - Download Excalibur (Maffhew)
            - [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur)
            - [Planet Minecraft](https://www.planetminecraft.com/texture-pack/excalibur/)
            - [Modrinth](https://modrinth.com/resourcepack/excal)


Special Thanks To:
══════════════════════════════════════════════════════════════════════════

    	Maffhew     		- For Excalibur and permission to maintain Vanilla Backport Support
	nocubeyt		- For Realm RPG: Fallen Adventurers and permission to upload to Curseforge and Modrinth
	Guardian            	- Author of this project, created most of the textures
	Ruseki			- Added remaining textures and revamped models


Excalibur License:
══════════════════════════════════════════════════════════════════════════

    Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
    http://creativecommons.org/licenses/by-nc-nd/3.0/us/

    In other words:
    - You may not redistribute this pack and claim it as your own.
    - You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
    - You may not put money-making links such as adf.ly with this work under any circumstances.
    - You may not use this work for commercial purposes.
    - You may not alter, transform, or build upon this work.

    Noncommercial Waiver
    - You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
    are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

    Any of the above conditions can be waived if you get permission from Maffhew.
    Discord: @maffhew
    

Realm RPG: Fallen Adventurers License:
══════════════════════════════════════════════════════════════════════════
- Author: nocubeyt

   - Source: https://www.curseforge.com/minecraft/mc-mods/realm-rpg-fallen-adventurers
   - License: ARR
   - This work is licensed under the All Rights Reserved License.

This work is protected under All Rights Reserved. You may not copy, distribute, modify, or use any part of this work without explicit permission from the author.

----------------------

This project’s original content is released under the following license:
All Rights Reserved.